# Governance Charter

*Draft for counsel. Not legal advice — entity structure, FCRA, and tax have real consequences you need an Indian lawyer and a CA for. The substance of what to lock down, and what will be attacked, is what this document is about.*

---

## The premise

Almost all governance is theatre. Mission statements, values decks, advisory boards, privacy policies — each survives exactly until it costs money.

Three things actually hold:

1. **Control someone else has**, that you cannot take back.
2. **A lock you cannot pick yourself**, even when you badly want to.
3. **A cost you pre-committed to paying**, in public, before you knew what it would cost.

Everything below is one of those three. If a proposed governance mechanism is none of them, it's decoration — cut it.

**Write these before the pressure arrives. It always arrives, and it arrives politely, from someone helpful, who has budget.**

---

## Part 1 — What you are actually building, stated plainly

A ranked, searchable, address-level database of India's poorest households, indexed by caste, religion, disability, pregnancy, and income.

That is the asset. It is enormously valuable to:

- **Political parties** — targeted welfare is targeted vote-buying; a list of SC households in a ward with their unmet entitlements is a campaign asset of extraordinary value
- **Lenders and insurers** — a pre-screened list of the financially desperate
- **The state** — a targeting list, which cuts both ways depending on who is in power and who is out of favour
- **An acquirer** — the only thing of value in a distressed sale

You will not be able to argue your way out of this by pointing at your good intentions. **Structure is the only defence.** Assume that at some point, someone with more power than you will want this data, and design so that you *cannot* give it to them even if you decide you want to.

---

## Part 2 — Entity structure

### Recommended: Section 8 company (non-profit), with a separate for-profit services arm only if truly needed

| Structure | Pro | Con | Verdict |
|---|---|---|---|
| **Section 8 company** | Profit lock-in by law. No dividends. Assets can't be distributed to members. Credible to government and NGOs. | Slower to raise capital. FCRA needed for foreign funds. | **Default. Choose this.** |
| Private limited (for-profit) | Easy capital, equity for talent, faster | **The database becomes a saleable asset owned by shareholders.** Acquisition, distressed sale, or an investor demanding "monetise the data" is a matter of when, not if. | Only with the locks in Part 3, and even then you're fighting your own cap table forever |
| Trust / Society | Simple, familiar to the sector | Weak governance machinery, harder for a mixed team | No |
| **Hybrid** (Sec 8 holds the data + a Pvt Ltd sells software to departments) | Capital + protection | Complexity, related-party scrutiny, and the temptation to leak data across the wall | Only if the SaaS revenue is genuinely material |

**If you go Section 8, the beneficiary database is owned by the Section 8 entity and can never be transferred.** Full stop. That single sentence in the articles is worth more than any privacy policy you will ever write.

**If you go for-profit anyway** (and there are honest reasons to — talent, speed, sustainability), then you *must* implement the golden share and the data trust in Part 3. Otherwise you are simply choosing to sell this data later and haven't admitted it to yourself yet.

---

## Part 3 — The locks

### Lock 1 — Constitutional commitments in the Articles of Association

Not the privacy policy. Policies are changed by a product manager on a Tuesday. **Articles require a supermajority and a filing.** Put these in the constitutional documents:

> **The Company shall not, under any circumstances:**
>
> 1. Sell, license, lease, or otherwise transfer the beneficiary database, or any derivative of it that permits re-identification, to any third party.
> 2. Provide bulk, case-level beneficiary data to any government department, political party, political actor, or commercial entity, absent the specific, named, informed consent of each data principal concerned.
> 3. Store Aadhaar numbers, biometrics, or the precise geolocation of any beneficiary's dwelling.
> 4. Compute, publish, or provide to any third party a composite score attached to an identified individual that could be used to rank, gate, or deny access to a benefit.
> 5. Use identified beneficiary data to train, fine-tune, or evaluate any machine-learning model.
> 6. Permit beneficiary data to pass to any acquirer, successor, or creditor in the event of sale, merger, insolvency, or wind-up. **Such data shall be destroyed or transferred to the designated Data Trust (Lock 3) as a condition precedent to any such event.**
>
> **Amendment of this clause requires:** (a) 90% shareholder/member approval, AND (b) the affirmative consent of the Independent Ethics Board, AND (c) ninety (90) days' public notice on the Company's website.

That last line is the actual lock. Not the prohibitions — **the amendment procedure.** Anyone can write a prohibition; the question is how cheaply a future version of you can delete it. Ninety days of public notice means the sector, your funders, and the press find out *before* it happens, not after.

### Lock 2 — The golden share

Issue a single share, with no economic rights, carrying a **veto over any amendment to the clause above and over any change of control.**

Hold it outside the company. Candidates, in rough order of preference:

- An established civil-society organisation with no financial stake and its own reputation to protect (a legal-aid body, a well-regarded rights organisation)
- A foundation with a track record of defending this kind of commitment
- A specially-constituted trust with named individuals of standing

**Do not hold it yourself. Do not let your lead investor hold it.** The entire point is that it is a power you have voluntarily and irrevocably given away, to someone who will use it against you when you are wrong. If holding the golden share is comfortable for you, you have given it to the wrong party.

### Lock 3 — The Data Trust and the destruction covenant

The beneficiary database is legally held by a **separate trust**, with the operating company as a *processor* under contract, not as owner.

Trust deed, key clauses:

- Beneficiaries (the households) are the beneficial owners of their own records.
- The operating company processes data **solely** for the enumerated purposes (P1–P4 in the DPDP architecture).
- **Termination trigger:** if the operating company is sold, becomes insolvent, changes control, or breaches the constitutional clause, the processing licence **terminates automatically** and the trustees must, within 30 days, either transfer the data to a successor bound by identical terms, or **destroy it.**
- Trustees include at least two people with **no** financial relationship to the company.

This is what makes clause 6 above enforceable rather than aspirational. Without it, "we promise not to let an acquirer have the data" is a sentence in a document that the acquirer's lawyers will delete during diligence.

### Lock 4 — The Ethics Board, with a real veto

An advisory board is worthless. Advice is free and ignorable. Give it **decision rights over a specific, enumerated list** — narrow enough to be usable, broad enough to matter.

**Composition (5–7 people):**
- 2 from civil society / rights organisations working with the affected communities
- 1 person **from a beneficiary community**, compensated properly for their time, not a token
- 1 data-protection lawyer
- 1 domain expert (welfare delivery, public administration)
- Max 1 person from the company
- **Chair is not from the company.**

**Hard veto** over:
- Any release of case-level data outside the organisation
- Any change to the refusal list or the data classification tiers
- Any new data category collected
- Any government or commercial data-sharing agreement
- Any change of control transaction

**Mandatory consultation** (must be heard, can be overruled — but the overrule is minuted and published in the transparency report):
- Product changes affecting how consent is obtained
- Changes to the eligibility rules engine's confidence thresholds
- Expansion to a new state or vertical

**Give the board its own budget, its own minutes, and the right to publish a dissent.** A board that cannot make its disagreement public is a board that has been captured and doesn't know it yet.

### Lock 5 — Pre-committed transparency report

Published quarterly, on a fixed date, on your website. **The date is committed in advance so that a bad quarter cannot become a skipped quarter.**

Contents, non-negotiable:

| Metric | Why it's here |
|---|---|
| **Received rate** (benefit in hand / identified) | The only metric that matters |
| **Our-fault rejection rate** | A team reporting 0% is not accurate, it is not looking |
| **Bribe reports involving our own agents** | If you won't publish this, you already know the answer |
| **Data requests refused, and from whom** (category, not name) | The only credible signal that your locks are real |
| **Ethics Board decisions, including dissents** | Proof the board isn't decorative |
| **Coverage gaps by block** | The embarrassing map. Publish it anyway. |
| **Erasure requests received and fulfilled, with median days** | Proves deletion actually runs |

The **"data requests refused"** line is the one that does the most work. It is cheap to publish, impossible to fake for long, and it is the only way an outsider can tell whether your governance is real or a brochure. It also creates a standing disincentive for anyone to make such a request in the first place — which is the point.

---

## Part 4 — Decision rights

| Decision | Founders | Board | Ethics Board | Golden Share |
|---|---|---|---|---|
| Product roadmap | **Decide** | Inform | — | — |
| Hiring, budget, ops | **Decide** | Approve | — | — |
| New data field collected | Propose | Inform | **Veto** | — |
| Government data-sharing MOU | Propose | Approve | **Veto** | — |
| Change to refusal list | Propose | Approve | **Veto** | **Veto** |
| Amend constitutional clause | Propose | 90% | **Veto** | **Veto** |
| Change of control / acquisition | Propose | Approve | **Veto** | **Veto** |
| Wind-down and data destruction | Propose | Approve | Consult | **Veto** |

Note what founders keep: **everything operational.** This is not a structure that makes you unable to run your company. It is a structure that makes you unable to do the four or five specific things that would destroy the reason it exists.

---

## Part 5 — Field integrity

The corruption you are most likely to produce is your own.

- **Fixed salaries. Never per-case, never per-conversion.** The moment an agent's income depends on a case closing, you have built a rent-extraction incentive into the last mile.
- **Independent beneficiary audit.** A team that does not report to the field manager phones a random 10% of households and asks: *did anyone ask you for money?* Including about our own staff, by name.
- **Publish that number.** Quarterly. Including when it is not zero.
- **One substantiated bribe by a field agent = termination.** Written into the employment contract before anyone is hired. No discretion, because discretion is where the exceptions come from.
- **Whistleblower protection with an external channel** — reports go to the Ethics Board chair, not to management. Any employee who reports in good faith cannot be terminated without Ethics Board review.
- **Referral routing is audited by someone outside the company.** Funder identity must not appear anywhere in the matcher's ranking inputs, and someone independent should check that annually.

---

## Part 6 — The founders' own commitment

Structures constrain the company. Something has to constrain the founders, because you are the ones who will be offered the deal.

Sign, publicly, at incorporation:

> We commit that we will not personally advocate for, vote for, or accept any transaction that transfers beneficiary data outside this organisation. If we are outvoted or overruled on such a transaction, we will **resign and say publicly why.**

This costs nothing today. That is exactly why you should sign it today — the day it costs something is the day it stops being signable.

---

## Part 7 — Wind-down

Most of these organisations die. Plan for yours honestly, while you still can.

**Trigger conditions for wind-down** (decided now, not in the panic):
- Runway below 3 months with no credible path
- Received rate below 15% for three consecutive quarters — *you are not helping anyone; stop consuming their trust*
- A structural breach of the constitutional clause that cannot be remedied

**On wind-down, in this order:**
1. Notify every household, by phone, in their language. They trusted you; they get told.
2. Hand every open case to a named live organisation or the statutory delivery point. **Nobody is dropped mid-case.**
3. Publish the coverage map, the rules engine, and the anonymised outcome data as a **public good.** It is the most valuable thing you made, and it should outlive you.
4. **Destroy the identified database.** Certified, audited, third-party-verified destruction.
5. Publish a post-mortem.

Step 4 is why Lock 3 exists. Without the Data Trust, step 4 is a promise made by an entity that no longer exists, about an asset a creditor is already claiming.

---

## What this costs you

Be clear-eyed. This structure will:

- Make you **slower to raise money.** Some investors will walk. The ones who walk over Lock 1 are telling you exactly what they intended to do with the data.
- **Cost you deals.** A department will offer real money for bulk access; you will say no and lose the contract.
- **Constrain a future pivot** you might genuinely believe in.
- Cost real money: ethics board fees, external audits, legal work. Budget **3–5% of opex.**

That is the price. It is worth paying, because without it you are building the most efficient targeting infrastructure for vulnerable people that India has ever had, and hoping that everyone who ever controls it is as good a person as you currently believe yourself to be.

**Hope is not a governance mechanism.**
