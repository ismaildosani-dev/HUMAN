# Verification Protocol

The registry is only worth something if `liveness` and `referral_capacity` are true.
Everything else can be scraped. These two must be walked.

---

## Stage 0 — Harvest (1 week, desk work, ~free)

Pull the raw candidate list for one district. Expect **400–900 rows** for a district like Pune. Expect **30–40% to be dead**.

| Source | What it gives you | Trap |
|---|---|---|
| NGO Darpan | Name, reg no., FCRA no., sectors, district, funding sources | Registration ≠ existence. Many are dormant. |
| MCA National CSR Portal | Which corporates funded whom, where, on what, how much | **The best liveness signal you can get for free.** Money moved last year = probably alive. |
| FCRA (MHA) | Foreign-funded orgs + annual returns | Filing a return is a strong liveness signal |
| IT 12A/80G lists | Tax-registered entities | |
| Charity Commissioner (MH) | Societies/trusts, state-level | Fragmented, often offline |
| District Collector's NGO panel | Orgs the *administration* actually uses | Small list, very high hit rate. Get this first. |
| DLSA, DCPU, One-Stop Centre, DDRC | Statutory bodies for legal aid, child protection, GBV, disability | These never appear in NGO databases and are often the **only** live option in a block |
| CSR/foundation grantee lists | Tata Trusts, Azim Premji, Wipro, HDFC Parivartan, local corporates | Names orgs that survived diligence |

**Dedup on `registration_no`, never on name.** Names collide, transliterate inconsistently, and change.

**Score each row for call priority** before you touch a phone:
`priority = 2·(recent CSR/grant money) + 2·(on district admin panel) + 1·(filed return in last 2y) + 1·(matches a pilot vertical)`

Call the top 150. Not all 900.

---

## Stage 1 — The phone call (10 min, ~50% will not answer)

This is the whole protocol. Everything else is scaffolding.

> **Opening.** "Namaskar, I'm calling from [org]. We help people in Haveli find out which government schemes they're entitled to. We're not funders and we're not from the government. When we find someone who needs help getting a disability certificate, we'd like to know who in this taluka can actually help them. Can I ask four questions? It'll take ten minutes."

Do not open with your mission statement. Do not mention data, platforms, or partnerships. You are asking them for help, not offering them a product. Orgs get sold to constantly and hang up.

**Q1 — Capability, asked concretely.**
> "If a 34-year-old man in Haveli with a locomotor disability and no certificate walked into your office tomorrow, what would you actually do for him?"

Never ask "do you work on disability?" — everyone says yes. Ask what they'd *do*. Then listen for whether they name specific steps, a specific hospital, a specific officer. Vague answers = they don't do this.

**Q2 — Geography, at block level.**
> "Which talukas do you actually go to? Not where you're registered — where your field staff physically went last month."

**Q3 — Capacity. The question nobody asks.**
> "How many new cases like this could you take on this month? And what's the wait?"

If they hesitate or inflate, ask: *"How many did you take last month?"* The gap between the two numbers tells you everything.

**Q4 — Referral mechanics.**
> "If we send someone to you, who do they ask for, and on what number? Would you be able to tell us later whether it got resolved?"

**Close by asking for two more names.** This is the highest-yield 20 seconds of the call:
> "Who else in this taluka actually does this work well?"

Snowball referrals from a verified org outperform Darpan by a wide margin, and `vouched_by` is a trust signal you cannot buy.

**Log the call whatever the outcome.** `UNREACHABLE` after 3 attempts on different days/times is *data*, not a failure — it prunes the ghost list.

---

## Stage 2 — Field visit (the ~40 that matter)

Phone verification gets you `PROBABLY_ACTIVE`. Only a physical visit gets `VERIFIED_ACTIVE`.

Visit any org you intend to send a vulnerable person to. Check:

- Is there an office, and are people in it?
- Are there **case files**? Ask to see (redacted) recent ones. An org that helps people has paper.
- Do the field staff exist, and do they speak the local language?
- Is there female staff, physically present? (Hard gate for GBV, shelter, maternal referrals — never take this on trust.)
- Is it wheelchair-accessible, and how far from a bus stop? A "free" service 8km from transport is not free to a poor person.
- **Ask a beneficiary in the waiting area, out of staff earshot: "did anyone ask you for money?"**

---

## Stage 3 — MOU, and the fallback that must always exist

Two tiers, deliberately:

- **Tier A — MOU signed.** DPDP processor agreement in place. You may transmit beneficiary data. They report outcomes back.
- **Tier B — no MOU.** You **show the citizen the org's public contact details and let them walk in themselves.** No data leaves your system.

**Tier B must always be available.** If your product only works when an NGO has signed your paperwork, you've built a partnership business, not a public good — and you will be tempted to route people to partners rather than to whoever is best.

---

## Stage 4 — Decay and re-walk

- Re-verify capacity **quarterly**. It's the field that rots fastest and the one whose staleness burns citizen trust.
- Liveness halves every ~120 days without contact. Below **0.25 → hard block from referrals.**
- A referral that gets accepted *is itself* a liveness ping. Free verification. Wire this up.
- **Any beneficiary report of money being asked for → immediate suspension**, investigate before reinstating. Not a score deduction. A suspension.

---

## Publish the gaps, not the count

The output that matters is not "we mapped 340 NGOs." It's:

> *"In Khed and Junnar taluka, there is **no live organisation** helping anyone obtain a disability certificate. In four talukas there is **nobody** doing scholarship application support."*

That coverage map is what gets you a meeting with the District Collector, what a CSR funder can actually act on, and what makes you useful rather than merely well-intentioned. It's also the honest answer to "what do you actually know that we don't."

---

## Three ways this goes wrong

1. **Your field agent becomes the new middleman.** They're trusted, they're in the village, they know which forms unlock money. Pay them a fixed salary, never per-case. Audit by calling beneficiaries directly and asking what they paid. Publish that number.
2. **Referral routing gets captured by whoever funds you.** If a CSR partner funds the pilot and also runs an NGO in the district, your matcher will find reasons to favour them. Keep funder identity out of the ranking inputs entirely, and let someone outside the company audit the routing.
3. **You map orgs instead of gaps.** Mapping is legible, fundable, and comfortable. Gaps are embarrassing and hard. Only one of them changes anything.
