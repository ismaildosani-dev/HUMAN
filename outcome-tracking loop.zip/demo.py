"""Synthetic 200-household pilot cohort. Numbers chosen to be realistic, not flattering."""
import random
from outcomes import (Case, funnel, branches, sanctioned_received_gap, rule_divergence,
                      integrity_signals, honesty_report)

random.seed(7)
BLOCKS = ["MH-PUN-HAVELI", "MH-PUN-MULSHI", "MH-PUN-KHED"]
cases: list[Case] = []


def make(i, scheme, block, path, state, bucket=None, code=None, exp=0.0, got=0.0,
         bribe=False, actor=None, days=None):
    return Case(f"C{i:03d}", f"HH{i:03d}", scheme, block, state, "LIKELY_ELIGIBLE", 7,
                "2026-03-01", path, bucket, code, None, days, exp, got, bribe, actor)


i = 0
# --- Scheme A: state disability pension. Tahsil office demands a domicile cert the GR
#     does not require. This is the divergence we want the loop to surface.
for _ in range(48):
    i += 1
    block = random.choice(BLOCKS)
    r = random.random()
    if r < 0.14:
        cases.append(make(i, "MH-SJSA-DISPEN-001", block, ["IDENTIFIED", "INFORMED"],
                          "ABANDONED", None, None))
    elif r < 0.62:
        cases.append(make(i, "MH-SJSA-DISPEN-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED", "UNDER_PROCESS"],
                          "REJECTED", "DOCUMENT_GAP", "NO_DOMICILE"))
    elif r < 0.70:
        cases.append(make(i, "MH-SJSA-DISPEN-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED", "UNDER_PROCESS"],
                          "REJECTED", "DISCRETIONARY", "ASKED_FOR_BRIBE",
                          bribe=True, actor="govt_office"))
    elif r < 0.80:
        cases.append(make(i, "MH-SJSA-DISPEN-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED", "UNDER_PROCESS", "SANCTIONED"],
                          "SANCTIONED", None, "BANK_NOT_DBT_SEEDED", exp=18000, got=0))
    else:
        cases.append(make(i, "MH-SJSA-DISPEN-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED", "UNDER_PROCESS",
                           "SANCTIONED", "RECEIVED"],
                          "RECEIVED", exp=18000, got=18000, days=random.randint(70, 160)))

# --- Scheme B: PMMVY. Our rule missed an exclusion -> OUR_FAULT cluster.
for _ in range(60):
    i += 1
    block = random.choice(BLOCKS)
    r = random.random()
    if r < 0.10:
        cases.append(make(i, "CENTRAL-MWCD-PMMVY-001", block, ["IDENTIFIED"],
                          "LOST_CONTACT"))
    elif r < 0.28:
        cases.append(make(i, "CENTRAL-MWCD-PMMVY-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED"],
                          "REJECTED", "OUR_FAULT", "RULE_MISSED_EXCLUSION"))
    elif r < 0.40:
        cases.append(make(i, "CENTRAL-MWCD-PMMVY-001", block,
                          ["IDENTIFIED", "INFORMED", "DOCS_PENDING"],
                          "ABANDONED", "DOCUMENT_GAP", "NO_BANK_ACCOUNT"))
    else:
        cases.append(make(i, "CENTRAL-MWCD-PMMVY-001", block,
                          ["IDENTIFIED", "INFORMED", "DOCS_PENDING", "APPLIED",
                           "UNDER_PROCESS", "SANCTIONED", "RECEIVED"],
                          "RECEIVED", exp=5000, got=5000, days=random.randint(40, 95)))

# --- Scheme C: ADIP. Mostly clean. One of OUR OWN agents took money in Khed.
for _ in range(40):
    i += 1
    block = random.choice(BLOCKS)
    r = random.random()
    if r < 0.08:
        cases.append(make(i, "CENTRAL-DEPWD-ADIP-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED"],
                          "REJECTED", "ADMINISTRATIVE", "BUDGET_EXHAUSTED"))
    elif r < 0.16 and block == "MH-PUN-KHED":
        cases.append(make(i, "CENTRAL-DEPWD-ADIP-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED", "UNDER_PROCESS",
                           "SANCTIONED", "RECEIVED"],
                          "RECEIVED", exp=4000, got=4000, bribe=True, actor="our_agent",
                          days=random.randint(50, 110)))
    else:
        cases.append(make(i, "CENTRAL-DEPWD-ADIP-001", block,
                          ["IDENTIFIED", "INFORMED", "APPLIED", "UNDER_PROCESS",
                           "SANCTIONED", "RECEIVED"],
                          "RECEIVED", exp=4000, got=4000, days=random.randint(50, 130)))

print(f"PILOT COHORT: {len(cases)} cases, 3 schemes, 3 blocks\n")

print("FUNNEL — where people actually fall out\n" + "-"*74)
print(f"  {'STATE':<16}{'COUNT':>7}{'% OF ID':>10}{'DROP':>8}{'STEP CONV':>12}")
for r in funnel(cases):
    d = r.get("drop_from_previous", "")
    s = f"{r.get('step_conversion','')}%" if "step_conversion" in r else ""
    print(f"  {r['state']:<16}{r['count']:>7}{r['pct_of_identified']:>9}%{str(d):>8}{s:>12}")

print("\n  BRANCH (reported beside the funnel, never inside it):")
for b in branches(cases):
    print(f"    {b['branch']:<16}{b['entered']:>7}{b['pct_of_identified']:>9}%   "
          f"escaped to APPLIED: {b['escaped_to_applied']} ({b['escape_rate_pct']}%)")
    print(f"    ^ {b['_note']}")

print("\n\nSANCTIONED -> RECEIVED GAP  ** the number nobody else has **\n" + "-"*74)
g = sanctioned_received_gap(cases)
print(f"  Department believes it paid : {g['sanctioned']} people, Rs {g['money_sanctioned']:,.0f}")
print(f"  Beneficiaries actually got  : {g['received']} people, Rs {g['money_in_hand']:,.0f}")
print(f"  LEAKAGE                     : {g['leakage_count']} people "
      f"({g['leakage_rate_pct']}%), Rs {g['money_unaccounted']:,.0f} unaccounted")
print(f"  Why it stuck                : {g['stuck_reasons']}")
print("\n  A department reporting 94% 'sanctioned' is not lying. It is measuring the")
print("  wrong edge. You are the only actor who phones the beneficiary.")

print("\n\nRULE DIVERGENCE — as written vs as practised\n" + "-"*74)
for f in rule_divergence(cases):
    print(f"\n  {f['scheme_id']}")
    print(f"    predicted eligible {f['predicted_eligible']}, rejected {f['rejected']} "
          f"({f['rejection_rate_pct']}%)")
    print(f"    dominant reason: {f['dominant_reason']} [{f['bucket']}] "
          f"— {f['cluster_share_pct']}% of rejections")
    print(f"    -> {f['action']}: {f['verdict']}")
    if f["field_note_draft"]:
        print(f"    FIELD NOTE (rule-as-written stays UNCHANGED):")
        print(f"      {f['field_note_draft']}")

print("\n\nINTEGRITY SIGNALS\n" + "-"*74)
sig = integrity_signals(cases)
for r in sig["by_block_actor"]:
    n = r["reports"] if r["reports"] is not None else f"<5 (suppressed)"
    print(f"  {r['block']:<16} {r['actor']:<14} reports={str(n):<16} {r['_publish_rule'][:44]}")
if sig["our_agent_alarm"]:
    print(f"\n  *** OUR OWN AGENTS: {sig['our_agent_reports']} bribe reports ***")
    print(f"  {sig['_our_agent_note']}")

print("\n\nHONESTY REPORT — what you publish, including the parts that hurt\n" + "-"*74)
for k, v in honesty_report(cases).items():
    if k.startswith("_"):
        continue
    print(f"  {k:<32} {v}")
print("\n  Note what is NOT here: 'lives touched', 'profiles created', 'schemes surfaced'.")
print("  Every one of those can be grown to infinity while helping nobody.")
