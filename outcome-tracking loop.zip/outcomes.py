"""
Outcome tracking loop.

Closes the circuit: the rules engine predicts, reality disagrees, the rules engine learns.
Without this you have a recommendation engine that never finds out whether it was right,
and a 'socio-economic platform' whose only feedback signal is its own optimism.

Three things this computes that nobody else in the system can:

  1. FUNNEL             — where people fall out, honestly, including our own fault
  2. SANCTIONED->RECEIVED GAP — money the state believes it paid, that nobody received
  3. RULE DIVERGENCE    — where the rule AS PRACTISED differs from the rule AS WRITTEN
"""

from __future__ import annotations
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date
from typing import Optional

FUNNEL_ORDER = ["IDENTIFIED", "INFORMED", "APPLIED",
                "UNDER_PROCESS", "SANCTIONED", "RECEIVED"]
BRANCH_STATES = ["DOCS_PENDING"]
"""DOCS_PENDING is a BRANCH, not a stage.

The first version of this listed it between INFORMED and APPLIED, which produced
'311% step conversion' and a negative drop — because some people route through it
and others skip it entirely. A funnel that reports >100% conversion is worse than
no funnel: it looks authoritative, it will end up in a board deck, and it is nonsense.

Report branches beside the funnel, never inside it.
"""
TERMINAL_BAD = {"REJECTED", "ABANDONED", "LOST_CONTACT"}


@dataclass
class Case:
    case_id: str
    profile_id: str
    scheme_id: str
    block: str
    state: str
    predicted_verdict: str            # what the rules engine said
    ruleset_version: int
    identified_on: str
    reached_states: list[str]
    rejection_bucket: Optional[str] = None
    rejection_code: Optional[str] = None
    beneficiary_account: Optional[str] = None   # what SHE said happened
    days_to_terminal: Optional[int] = None
    amount_expected: float = 0.0
    amount_received: float = 0.0
    bribe_reported: bool = False
    bribe_actor: Optional[str] = None           # "govt_office" | "middleman" | "our_agent"


def funnel(cases: list[Case]) -> list[dict]:
    """Where do people fall out? Report absolute counts, not just rates —
    a 90% conversion on 10 people is not a result."""
    n0 = len(cases)
    rows = []
    for state in FUNNEL_ORDER:
        reached = sum(1 for c in cases if state in c.reached_states)
        rows.append({
            "state": state,
            "count": reached,
            "pct_of_identified": round(100 * reached / n0, 1) if n0 else 0.0,
        })
    for i in range(1, len(rows)):
        prev, cur = rows[i - 1]["count"], rows[i]["count"]
        rows[i]["drop_from_previous"] = prev - cur
        rows[i]["step_conversion"] = round(100 * cur / prev, 1) if prev else 0.0

    # sanity guard: a funnel can never gain people. If it does, the state model is wrong.
    for r in rows[1:]:
        assert r["step_conversion"] <= 100.0, (
            f"funnel gained people at {r['state']} — a non-linear state is in FUNNEL_ORDER")
    return rows


def branches(cases: list[Case]) -> list[dict]:
    """Side-branches, reported BESIDE the funnel so they can't corrupt it."""
    n0 = len(cases)
    out = []
    for state in BRANCH_STATES:
        hit = [c for c in cases if state in c.reached_states]
        escaped = [c for c in hit if "APPLIED" in c.reached_states]
        out.append({
            "branch": state,
            "entered": len(hit),
            "pct_of_identified": round(100 * len(hit) / n0, 1) if n0 else 0.0,
            "escaped_to_applied": len(escaped),
            "escape_rate_pct": round(100 * len(escaped) / len(hit), 1) if hit else 0.0,
            "_note": "People stuck here are SERVICEABLE, not lost. Route to a "
                     "documentation-assistance org and re-open the case.",
        })
    return out


def sanctioned_received_gap(cases: list[Case]) -> dict:
    """THE number nobody else has.

    Departments report 'sanctioned' and call it done. The beneficiary reports whether
    anything landed. The delta is DBT seeding failures, dormant accounts, name mismatches,
    money parked in intermediary accounts, and leakage.

    You are the only actor in the system who phones the beneficiary, which makes you the
    only actor who can measure this edge. It is your single strongest argument for existing.
    """
    sanctioned = [c for c in cases if "SANCTIONED" in c.reached_states]
    received = [c for c in sanctioned if "RECEIVED" in c.reached_states]

    expected = sum(c.amount_expected for c in sanctioned)
    actual = sum(c.amount_received for c in sanctioned)

    stuck = [c for c in sanctioned if "RECEIVED" not in c.reached_states]
    stuck_reasons = Counter(c.rejection_code or "NO_REASON_CAPTURED" for c in stuck)

    return {
        "sanctioned": len(sanctioned),
        "received": len(received),
        "leakage_count": len(stuck),
        "leakage_rate_pct": round(100 * len(stuck) / len(sanctioned), 1) if sanctioned else 0.0,
        "money_sanctioned": expected,
        "money_in_hand": actual,
        "money_unaccounted": expected - actual,
        "stuck_reasons": dict(stuck_reasons),
    }


def rule_divergence(cases: list[Case], min_rejections: int = 5,
                    cluster_threshold: float = 0.5) -> list[dict]:
    """Rule as WRITTEN vs rule as PRACTISED.

    Fires when we predicted eligible, the department said no, and the rejection reasons
    CLUSTER on one code. A cluster means the office is applying a rule our ruleset doesn't
    know about — or is applying one it has no right to.

    Note the deliberate design: we do NOT auto-patch the rule. Overwriting the official
    rule with observed local practice would (a) destroy your ability to tell a citizen
    'you were wrongly denied' and (b) quietly launder an illegal demand into your product.
    Rule-as-written and rule-as-practised stay separate fields, forever.
    """
    by_scheme: dict[str, list[Case]] = defaultdict(list)
    for c in cases:
        if c.predicted_verdict in ("ELIGIBLE", "LIKELY_ELIGIBLE") and "APPLIED" in c.reached_states:
            by_scheme[c.scheme_id].append(c)

    findings = []
    for sid, cs in by_scheme.items():
        rejected = [c for c in cs if c.state == "REJECTED"]
        if len(rejected) < min_rejections:
            continue

        codes = Counter(c.rejection_code for c in rejected if c.rejection_code)
        if not codes:
            continue
        top_code, top_n = codes.most_common(1)[0]
        share = top_n / len(rejected)
        if share < cluster_threshold:
            continue

        bucket = next((c.rejection_bucket for c in rejected if c.rejection_code == top_code), None)

        if bucket == "OUR_FAULT":
            verdict = "RULE DEFECT — our ruleset is wrong. Open a defect, add a golden fixture."
            action = "FIX_OUR_RULE"
        elif bucket == "DOCUMENT_GAP":
            verdict = ("PRE-CONDITION MISSED — we should surface this document requirement "
                       "BEFORE telling them to apply.")
            action = "ADD_BLOCKING_DOCUMENT_WARNING"
        elif bucket == "DISCRETIONARY":
            verdict = ("PRACTICE DIVERGENCE — the office is refusing beyond the written rule. "
                       "Do NOT encode this as an eligibility rule. Escalate it.")
            action = "ESCALATE_DO_NOT_ENCODE"
        else:
            verdict = "SYSTEMIC — administrative failure, not an eligibility question."
            action = "AGGREGATE_AND_ESCALATE"

        findings.append({
            "scheme_id": sid,
            "predicted_eligible": len(cs),
            "rejected": len(rejected),
            "rejection_rate_pct": round(100 * len(rejected) / len(cs), 1),
            "dominant_reason": top_code,
            "bucket": bucket,
            "cluster_share_pct": round(100 * share, 1),
            "verdict": verdict,
            "action": action,
            "field_note_draft": (
                f"OBSERVED (n={top_n}, {sid}): applications are being rejected for "
                f"'{top_code}' although the written rule does not require it. "
                f"Rule-as-written UNCHANGED. Warn the citizen; raise with the department."
            ) if bucket == "DISCRETIONARY" else None,
        })

    return sorted(findings, key=lambda f: -f["rejected"])


def integrity_signals(cases: list[Case], k: int = 30) -> dict:
    """Bribe reporting — including about OUR OWN agents.

    If you are not willing to measure whether your own field staff took a cut, you are
    not fighting corruption. You are relocating it, and adding a layer of respectability
    on top.

    Aggregated by BLOCK and ACTOR TYPE. Never by named individual: you cannot defend a
    defamation suit, and your field team lives in those villages.
    """
    by_block_actor: dict[tuple, int] = defaultdict(int)
    totals: dict[str, int] = defaultdict(int)

    for c in cases:
        totals[c.block] += 1
        if c.bribe_reported:
            by_block_actor[(c.block, c.bribe_actor or "unknown")] += 1

    rows, own_agent_total = [], 0
    for (block, actor), n in sorted(by_block_actor.items()):
        if actor == "our_agent":
            own_agent_total += n
        rows.append({
            "block": block,
            "actor": actor,
            "reports": n if n >= 5 else None,
            "suppressed": n < 5,
            "rate_pct": round(100 * n / totals[block], 1) if totals[block] else 0.0,
            "publishable": n >= k,
            "_publish_rule": (
                "PUBLISHABLE with documented methodology" if n >= k
                else f"NOT publishable (n={n} < {k}). Escalate through the statutory "
                     f"grievance channel first. One case is a complaint; {k}+ is a finding."
            ),
        })

    return {
        "by_block_actor": rows,
        "our_agent_reports": own_agent_total,
        "our_agent_alarm": own_agent_total > 0,
        "_our_agent_note": (
            "ANY non-zero count here is a five-alarm fire. Your field agent is the new "
            "middleman — trusted, local, knows which forms unlock money. Suspend, "
            "investigate, and PUBLISH the number. Publishing it is the only credible signal "
            "you can send; if you won't publish it, you already know the answer."
        ),
    }


def honesty_report(cases: list[Case]) -> dict:
    """The metrics we hold ourselves to. Publish these, including the unflattering ones."""
    n = len(cases)
    applied = [c for c in cases if "APPLIED" in c.reached_states]
    received = [c for c in cases if "RECEIVED" in c.reached_states]
    our_fault = [c for c in cases if c.rejection_bucket == "OUR_FAULT"]
    abandoned = [c for c in cases if c.state == "ABANDONED"]
    doc_gap = [c for c in cases if c.rejection_bucket == "DOCUMENT_GAP"]
    days = [c.days_to_terminal for c in received if c.days_to_terminal]

    return {
        "NORTH_STAR_received_rate_pct": round(100 * len(received) / n, 1) if n else 0.0,
        "identified": n,
        "received": len(received),
        "median_days_to_benefit": sorted(days)[len(days) // 2] if days else None,
        "our_fault_rate_pct": round(100 * len(our_fault) / len(applied), 1) if applied else 0.0,
        "abandonment_rate_pct": round(100 * len(abandoned) / n, 1) if n else 0.0,
        "document_gap_rate_pct": round(100 * len(doc_gap) / n, 1) if n else 0.0,
        "money_in_hand": sum(c.amount_received for c in cases),
        "_note": ("our_fault_rate is the honesty metric. A team that reports 0% is not "
                  "accurate, it is not looking. Publish it."),
    }
