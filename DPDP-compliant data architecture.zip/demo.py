from datetime import date
from policy_engine import (PolicyEngine, PolicyViolation, grant_consent,
                           retention_sweep, safe_aggregate, CONSENT_SCRIPT)

TODAY = date(2026, 7, 12)
eng = PolicyEngine("data_classification.json")

PROFILE = {
    "block_lgd": "MH-PUN-HAVELI",
    "preferred_language": "mr",
    "has_aadhaar": True,
    "has_bank_account": True,
    "age": 34,
    "gender": "male",
    "annual_household_income": 96000,
    "education_stage": "not_studying",
    "social_category": "SC",              # T2
    "disability_percentage": 85,          # T2
    "disability_type": "locomotor",       # T2
    "is_pregnant": False,                 # T2
}

consent = grant_consent(
    principal_id="HH-0042",
    purposes={"P1_ELIGIBILITY_CHECK", "P2_REFERRAL", "P3_OUTCOME_TRACKING"},
    recipients={"ORG-MH-PUN-0011"},        # ONE named org. Not "our partners".
    agent_id="agent_17", lang="mr",
    audio_ref="s3://consent/HH-0042.opus", today=TODAY,
)

print("CONSENT SCRIPT (read aloud, ~60 seconds)\n" + "-"*72)
for line in CONSENT_SCRIPT["en_gloss"]:
    print(f"  {line}")
print(f"\n  method={consent.method}  script_hash={consent.script_hash}  witness={consent.witness_id}")

print("\n\nSCENARIO 1 — Field agent opens the case (legitimate)\n" + "-"*72)
vis, audit = eng.read_profile(PROFILE, "FIELD_AGENT", "P1_ELIGIBILITY_CHECK",
                              consent, "agent_17", today=TODAY)
print(f"  VISIBLE : {sorted(vis)}")
denied = sorted({a['fact_key'] for a in audit if a['decision'] == 'DENY'})
print(f"  HIDDEN  : {denied}")
print("  ^ The agent ENTERED her caste and disability. He cannot read them back.")
print("    Write-without-read. He cannot build a list of SC households in his block.")

print("\n\nSCENARIO 2 — Agent tries to browse T2 directly\n" + "-"*72)
ok, why = eng.check_read("social_category", "FIELD_AGENT", "P1_ELIGIBILITY_CHECK", consent)
print(f"  read social_category as FIELD_AGENT -> {ok}: {why}")
ok, why = eng.check_write("social_category", "FIELD_AGENT")
print(f"  write social_category as FIELD_AGENT -> {ok}: {why}")

print("\n\nSCENARIO 3 — Analyst tries to reach an identified profile\n" + "-"*72)
vis, _ = eng.read_profile(PROFILE, "ANALYST", "P4_AGGREGATE_INSIGHT", consent, "analyst_3")
print(f"  ANALYST sees: {vis}   <- empty. There is NO path from an analyst seat")
print("                            to an identified person. Not a discouraged path. None.")

print("\n\nSCENARIO 4 — Referral to the CONSENTED org (data minimisation)\n" + "-"*72)
payload, withheld = eng.build_referral_payload(
    PROFILE, "DISABILITY_CERTIFICATE_ASSISTANCE", "ORG-MH-PUN-0011",
    ["DISABILITY_CERTIFICATE_ASSISTANCE", "ASSISTIVE_DEVICE"], consent, "agent_17", TODAY)
print(f"  SENT    : {sorted(payload)}")
print(f"  WITHHELD: {sorted(withheld)}")
print("  ^ The disability org gets disability data. It does NOT get her caste or income,")
print("    even though we hold them and the org would happily take them.")

print("\n\nSCENARIO 5 — Referral to an org she never consented to  ** THE ATTACK **\n" + "-"*72)
try:
    eng.build_referral_payload(PROFILE, "DISABILITY_CERTIFICATE_ASSISTANCE",
                               "ORG-MH-PUN-0044",
                               ["DISABILITY_CERTIFICATE_ASSISTANCE"], consent, "agent_17", TODAY)
except PolicyViolation as e:
    print(f"  BLOCKED: {e}")
print("  ^ This is the one that matters. A new CSR partner signs next quarter and")
print("    someone says 'just route the existing cases to them'. Consent to BE HELPED")
print("    is not consent to be SENT to Org X. The org is named, or it does not happen.")

print("\n\nSCENARIO 6 — Govt department asks for 'the list of beneficiaries in this ward'\n" + "-"*72)
vis, _ = eng.read_profile(PROFILE, "GOVT_DEPARTMENT", "P1_ELIGIBILITY_CHECK", consent, "dept_1")
print(f"  GOVT_DEPARTMENT sees: {vis}   <- empty by default.")
print("  Departments get P4 AGGREGATES. Case-level data requires her explicit,")
print("  named, per-department consent — and only from a dept actually delivering to her.")
print("  'Give us the list of beneficiaries in this ward' is the request that turns")
print("  a welfare tool into a targeting tool. Refuse it in code, not in a meeting.")

print("\n\nSCENARIO 7 — Unclassified field added last sprint (fail closed)\n" + "-"*72)
print(f"  tier_of('some_new_field_someone_added') = {eng.tier_of('some_new_field_someone_added')}")
print("  ^ Defaults to T2_SENSITIVE, not T0. A field nobody classified must not")
print("    silently become visible to every field agent.")

print("\n\nSCENARIO 8 — Retention sweep actually deletes\n" + "-"*72)
kept, purged = retention_sweep(
    PROFILE, {"last_contact_at": "2026-05-01", "case_closed_at": "2026-03-01"}, eng, TODAY)
print(f"  PURGED: {purged}")
print(f"  KEPT  : {sorted(kept)}")
kept2, purged2 = retention_sweep(PROFILE, {"last_contact_at": "2024-01-01"}, eng, TODAY)
print(f"  24mo dormant -> {purged2}")

print("\n\nSCENARIO 9 — Coverage map, k-anonymised\n" + "-"*72)
rows = ([{"block": "MH-PUN-HAVELI", "need": "UDID"}] * 40 +
        [{"block": "MH-PUN-JUNNAR", "need": "UDID"}] * 3 +
        [{"block": "MH-PUN-MULSHI", "need": "GBV_SUPPORT"}] * 2)
for r in safe_aggregate(rows, ["block", "need"], k=25):
    if r["suppressed"]:
        print(f"  {r['block']:<16} {r['need']:<14} SUPPRESSED ({r['reason']})")
    else:
        print(f"  {r['block']:<16} {r['need']:<14} {r['count']}")
print("  ^ Two GBV cases in Mulshi is not a statistic, it is two identifiable women.")
print("    The coverage map is exactly where small cells appear. Suppress, always.")
