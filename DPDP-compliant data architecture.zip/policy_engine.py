"""
DPDP policy engine.

The point: purpose limitation, consent, and role scoping are enforced IN CODE at
the data-access boundary. Not in a policy PDF. Not in a code review checklist.
Not in a training deck. In the function call that returns the data.

If a developer can write `SELECT * FROM profiles` and get a caste column back,
you do not have a compliant system, you have a compliant document.

Three controls do most of the work:

  1. PURPOSE BINDING     — every read declares a purpose; the purpose gates the tiers.
  2. WRITE-WITHOUT-READ  — field agents can enter T2 (caste, pregnancy, disability)
                           but can never read it back, list it, or export it.
  3. NAMED-RECIPIENT     — consent to "be helped" is never consent to send data to
     CONSENT              Org X. The org is named at consent time, every time.
"""

from __future__ import annotations
import hashlib, json
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional


class PolicyViolation(Exception):
    """Raised at the access boundary. Never caught and logged-and-continued.
    A policy violation is a bug in the caller, not a runtime condition to absorb."""


# ------------------------------------------------------------------ consent artifact

@dataclass
class Consent:
    """A consent record that would survive a regulator asking 'prove she understood'.

    Deliberately NOT a checkbox. A checkbox ticked by a field agent on behalf of a
    woman who cannot read is not consent; it is paperwork. What makes this defensible:
      - the exact script read aloud is recorded, in her language
      - an audio recording of HER saying yes (with consent to record)
      - granular: per purpose, per named recipient
      - revocable by phone call, and revocation actually propagates
    """
    principal_id: str
    purposes: set[str]
    named_recipients: set[str] = field(default_factory=set)
    language: str = "mr"
    script_version: str = "v1"
    script_hash: str = ""
    method: str = "verbal_audio_recorded"   # verbal_audio_recorded | thumbprint_paper | app_self_serve
    witness_id: Optional[str] = None        # agent who read it
    granted_at: str = ""
    expires_at: str = ""
    revoked_at: Optional[str] = None
    audio_ref: Optional[str] = None

    def is_valid(self, today: Optional[date] = None) -> bool:
        today = today or date.today()
        if self.revoked_at:
            return False
        return date.fromisoformat(self.expires_at) >= today

    def covers(self, purpose: str, recipient: Optional[str] = None,
               today: Optional[date] = None) -> tuple[bool, str]:
        if not self.is_valid(today):
            return False, "consent expired or revoked"
        if purpose not in self.purposes:
            return False, f"consent does not cover purpose {purpose}"
        if recipient and recipient not in self.named_recipients:
            # THE control that prevents "consent to be helped" being laundered into
            # "consent to ship her file to whoever we partner with next quarter".
            return False, (f"consent does not name recipient '{recipient}'. "
                           f"Re-consent required, naming this organisation.")
        return True, "ok"


CONSENT_SCRIPT = {
    "mr": [
        "आम्ही तुमची माहिती विचारत आहोत, फक्त एका कारणासाठी: तुम्हाला कोणत्या सरकारी योजना मिळू शकतात हे सांगण्यासाठी.",
        "तुम्ही 'नाही' म्हणालात तरी चालेल. त्याने तुमचे कोणतेही सरकारी हक्क कमी होणार नाहीत.",
        "आम्ही तुमची माहिती कोणालाही विकणार नाही.",
        "आम्ही ती फक्त त्या संस्थेला पाठवू जिचे नाव आम्ही तुम्हाला आधी सांगू — आणि तुमची परवानगी घेऊ.",
        "तुम्ही कधीही फोन करून सांगू शकता की 'माझी माहिती काढून टाका'. आम्ही ती काढून टाकू.",
        "हा नंबर लिहून ठेवा: ________. तक्रार असल्यास इथे फोन करा.",
    ],
    "en_gloss": [
        "We are asking for your information for one reason only: to tell you which government schemes you can get.",
        "You can say no. Saying no will not reduce any government entitlement you already have.",
        "We will not sell your information to anyone.",
        "We will only send it to an organisation whose name we tell you first — and we will ask you first.",
        "You can call and say 'delete my information' at any time. We will delete it.",
        "Write down this number: ________. Call here if you have a complaint.",
    ],
}
"""Six lines. Read aloud. Under 60 seconds.

Note what is NOT in it: no 'data controller', no 'processing', no 'legitimate interest',
no 'as described in our privacy policy'. A consent script a person cannot understand is
not a consent script, it is a liability shield — and it will not shield you anyway.

Line 2 is the most important and the most often omitted. Without it, consent given to
a stranger who appears to control access to benefits is not freely given, and therefore
is not consent.
"""


def script_hash(lang: str) -> str:
    return hashlib.sha256(json.dumps(CONSENT_SCRIPT[lang]).encode()).hexdigest()[:16]


def grant_consent(principal_id: str, purposes: set[str], recipients: set[str],
                  agent_id: str, lang: str = "mr", audio_ref: Optional[str] = None,
                  today: Optional[date] = None, validity_days: int = 365) -> Consent:
    today = today or date.today()
    return Consent(
        principal_id=principal_id,
        purposes=set(purposes),
        named_recipients=set(recipients),
        language=lang,
        script_version="v1",
        script_hash=script_hash(lang),
        method="verbal_audio_recorded" if audio_ref else "thumbprint_paper",
        witness_id=agent_id,
        granted_at=today.isoformat(),
        expires_at=(today + timedelta(days=validity_days)).isoformat(),
        audio_ref=audio_ref,
    )


# ------------------------------------------------------------------ policy engine

class PolicyEngine:
    def __init__(self, classification_path: str):
        with open(classification_path) as f:
            self.cfg = json.load(f)
        self.tiers = self.cfg["sensitivity_tiers"]
        self.purposes = self.cfg["purposes"]
        self.roles = self.cfg["roles"]

        # fact_key -> tier, built from the classification examples
        self.fact_tier: dict[str, str] = {}
        for tier, spec in self.tiers.items():
            for fk in spec["examples"]:
                self.fact_tier[fk] = tier

    def tier_of(self, fact_key: str) -> str:
        # Unclassified facts are treated as SENSITIVE, not as operational.
        # Fail closed. A new field someone added last sprint must not default to
        # 'visible to every field agent'.
        return self.fact_tier.get(fact_key, "T2_SENSITIVE")

    def check_read(self, fact_key: str, role: str, purpose: str,
                   consent: Optional[Consent], recipient: Optional[str] = None,
                   today: Optional[date] = None) -> tuple[bool, str]:
        tier = self.tier_of(fact_key)

        p = self.purposes.get(purpose)
        if p is None:
            return False, f"unknown purpose '{purpose}'"
        if p.get("blocked"):
            return False, f"purpose '{purpose}' is permanently blocked"

        if tier not in p.get("allowed_tiers", []):
            return False, f"purpose '{purpose}' may not access tier {tier}"

        r = self.roles.get(role)
        if r is None:
            return False, f"unknown role '{role}'"
        if tier not in r.get("can_read", []):
            return False, f"role '{role}' cannot read tier {tier}"

        if p.get("consent_required"):
            if consent is None:
                return False, "no consent on file"
            need_recipient = recipient if p.get("consent_is_per_recipient") else None
            ok, why = consent.covers(purpose, need_recipient, today)
            if not ok:
                return False, why

        return True, "ok"

    def check_write(self, fact_key: str, role: str) -> tuple[bool, str]:
        tier = self.tier_of(fact_key)
        r = self.roles.get(role, {})
        if tier not in r.get("can_write", []):
            return False, f"role '{role}' cannot write tier {tier}"
        return True, "ok"

    def read_profile(self, profile: dict, role: str, purpose: str,
                     consent: Optional[Consent], actor_id: str,
                     recipient: Optional[str] = None,
                     today: Optional[date] = None) -> tuple[dict, list[dict]]:
        """THE access boundary. Nothing reads a profile except through this.

        Returns (visible_facts, audit_entries). Denied fields are ABSENT, not None —
        so a caller cannot distinguish 'she has no caste certificate' from
        'you may not see her caste'. That distinction is itself a leak.
        """
        visible, audit = {}, []
        for fk, value in profile.items():
            ok, why = self.check_read(fk, role, purpose, consent, recipient, today)
            if ok:
                visible[fk] = value
            audit.append({
                "actor": actor_id, "role": role, "purpose": purpose,
                "fact_key": fk,                # KEY only
                "tier": self.tier_of(fk),
                "decision": "ALLOW" if ok else "DENY",
                "reason": why,
                "recipient": recipient,
                "at": datetime.now(timezone.utc).isoformat(),
                # NOTE: the audit log NEVER contains the fact VALUE. An audit log of
                # who-looked-at-whose-caste is itself a caste database.
            })
        return visible, audit

    def build_referral_payload(self, profile: dict, need_code: str, org_id: str,
                               org_capabilities: list[str], consent: Optional[Consent],
                               actor_id: str, today: Optional[date] = None
                               ) -> tuple[dict, list[str]]:
        """Minimum viable referral. Send the least that lets them help.

        A disability org gets disability_percentage. It does NOT get religion,
        pregnancy status, or income history — even though we hold them, even though
        the org would happily accept them, and even though it would be one less
        question for them to ask.
        """
        if need_code not in org_capabilities:
            raise PolicyViolation(f"{org_id} does not serve {need_code}; refusing to send data")

        ok, why = (consent.covers("P2_REFERRAL", org_id, today)
                   if consent else (False, "no consent"))
        if not ok:
            raise PolicyViolation(f"cannot refer to {org_id}: {why}")

        NEED_TO_FACTS = {
            "DISABILITY_CERTIFICATE_ASSISTANCE": ["age", "gender", "disability_percentage",
                                                  "disability_type", "block_lgd",
                                                  "preferred_language", "has_aadhaar"],
            "ASSISTIVE_DEVICE": ["age", "gender", "disability_percentage", "disability_type",
                                 "block_lgd", "annual_household_income", "preferred_language"],
            "ANTENATAL_CARE": ["age", "is_pregnant", "block_lgd", "preferred_language",
                               "has_bank_account"],
            "BANK_ACCOUNT_OPENING": ["age", "gender", "block_lgd", "has_aadhaar",
                                     "preferred_language"],
            "SCHOLARSHIP_APPLICATION": ["age", "education_stage", "is_student",
                                        "social_category", "annual_household_income",
                                        "block_lgd", "preferred_language"],
        }
        allowed = NEED_TO_FACTS.get(need_code, [])
        payload, withheld = {}, []
        for fk, v in profile.items():
            if fk in allowed:
                payload[fk] = v
            else:
                withheld.append(fk)
        return payload, withheld


# ------------------------------------------------------------------ retention

def retention_sweep(profile: dict, meta: dict, engine: PolicyEngine,
                    today: Optional[date] = None) -> tuple[dict, list[str]]:
    """Deletion is a feature that must RUN, not a promise in a policy.

    Wire this to a cron. Alert if it hasn't run in 48h. A retention rule that has
    never actually deleted anything is not a control, it's a claim.
    """
    today = today or date.today()
    purged = []
    out = dict(profile)

    last_contact = date.fromisoformat(meta["last_contact_at"])
    if (today - last_contact).days > 730:
        return {}, ["FULL_PURGE: no contact 24 months"]

    if meta.get("case_closed_at"):
        closed = date.fromisoformat(meta["case_closed_at"])
        if (today - closed).days > 90:
            for fk in list(out):
                if engine.tier_of(fk) == "T2_SENSITIVE":
                    del out[fk]
                    purged.append(f"{fk} (T2, 90d post-closure)")

    for fk in list(out):
        if engine.tier_of(fk) == "T3_CRISIS":
            del out[fk]
            purged.append(f"{fk} (T3, unconditional)")

    return out, purged


# ------------------------------------------------------------------ k-anonymity

def safe_aggregate(rows: list[dict], group_keys: list[str], k: int = 25) -> list[dict]:
    """P4 aggregates. Suppress any cell below k.

    'One unique 34-year-old transgender person with 85% disability in Junnar block'
    is not anonymous, no matter what the column headers say. Small cells are the
    entire re-identification attack surface, and the coverage map is exactly where
    small cells appear.
    """
    buckets: dict[tuple, int] = {}
    for r in rows:
        key = tuple(r.get(g) for g in group_keys)
        buckets[key] = buckets.get(key, 0) + 1

    out = []
    for key, count in sorted(buckets.items()):
        rec = dict(zip(group_keys, key))
        if count < k:
            rec["count"] = None
            rec["suppressed"] = True
            rec["reason"] = f"cell size {count} < k={k}"
        else:
            rec["count"] = count
            rec["suppressed"] = False
        out.append(rec)
    return out
