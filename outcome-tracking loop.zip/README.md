# The Outcome-Tracking Loop

The piece that makes everything before it real. Without it you have a recommendation engine that never learns whether it was right — and a "socio-economic platform" whose only feedback signal is its own optimism.

```
case_lifecycle.json  States, rejection taxonomy, follow-up protocol, banned metrics
outcomes.py          Funnel, sanctioned→received gap, rule divergence, integrity signals
demo.py              148-case synthetic pilot. Run it.
```

## The only metric

**Benefit actually received, in hand.**

Not profiles created. Not schemes surfaced. Not referrals sent. Not "lives touched." Every one of those can be grown to infinity while helping nobody, and every welfare-tech org that quietly died did so with a green dashboard.

The demo cohort lands at **52% received rate**. That's a plausible-to-good real number, and it's the one you publish.

## The number nobody else has

```
Department believes it paid : 83 people, Rs 509,000
Beneficiaries actually got  : 77 people, Rs 401,000
LEAKAGE                     : 6 people (7.2%), Rs 108,000 unaccounted
Why it stuck                : {'BANK_NOT_DBT_SEEDED': 6}
```

`SANCTIONED → RECEIVED` is the edge every government dashboard treats as automatic. It isn't. Money is "released" and never lands — account not DBT-seeded, dormant, name mismatch, rejected credit, parked in an intermediary account, or skimmed.

A department reporting 94% sanctioned is **not lying**. It's measuring the wrong edge. **You are the only actor in the system who phones the beneficiary**, which makes you the only one who can measure this one. It is your single strongest argument for existing, and it's what gets you in the room with a Collector.

## Rule-as-written vs rule-as-practised

```
MH-SJSA-DISPEN-001 — 29/39 rejected; 93% cite NO_DOMICILE
CENTRAL-MWCD-PMMVY-001 — 15 rejected; 100% RULE_MISSED_EXCLUSION → our bug
```

The engine routes each cluster differently, and the routing is the whole point:

- `OUR_FAULT` → **fix the rule**, open a defect, add a golden fixture.
- `DOCUMENT_GAP` → **warn earlier**; we sent people to a counter we knew would turn them away.
- `DISCRETIONARY` → **escalate, do not encode.**

That last one matters most. If an office demands a document the GR doesn't require, the tempting move is to add it to your eligibility rules — the rejection rate drops, the dashboard improves. **Don't.** Overwriting the written rule with observed local practice destroys your ability to tell a citizen *"you were wrongly denied,"* and quietly launders an illegal demand into your product. Keep `rule_as_written` and `rule_as_practised` as separate fields, forever. Warn the citizen; report the office.

## The fourth follow-up question

Every call, without exception:

> *"Did anyone ask you for money — at the office, or to fill the form?"*

**Including about your own agents, by name.** The demo deliberately plants three such reports, and the system escalates them as a five-alarm fire.

If you are not willing to measure whether your own field staff took a cut, you are not fighting corruption — you are relocating it and adding a layer of respectability on top. Your agent is trusted, local, and knows which forms unlock money. That is the *definition* of the middleman you set out to remove.

**Publish that number.** It's the only credible signal you can send. If you won't publish it, you already know the answer.

## Handle the discretionary bucket carefully

You'll soon hold data saying: *at this office, poor people are asked for bribes at 5× the district rate.* That's valuable. It's also the fastest route to a threatened field team and a revoked Collector relationship. Rules decided **before** you have the data:

1. Aggregate by **office and post**, never by named individual. You can't defend a defamation suit.
2. Publish nothing below ~30 independent reports with a documented methodology.
3. Escalate through the **statutory channel first** (grievance portal, DLSA, Lokayukta). On the record. That record is your protection later.
4. The **beneficiary** decides whether to file a complaint. Never file in their name without consent — they live in that village, you don't.

## The bug the demo caught

First run, the funnel reported **311% step conversion** at `APPLIED`, with a *negative* drop. `DOCS_PENDING` was sitting in the linear funnel, but it's a **branch** — some route through it, some skip it.

Fixed by pulling branches out and adding an assertion that a funnel can never gain people. A funnel reporting >100% conversion is worse than no funnel: it looks authoritative, it ends up in a board deck, and it is nonsense. The assertion stays in.

## Publish the honesty metrics

```
NORTH_STAR_received_rate_pct     52.0
our_fault_rate_pct               11.5   <- we told 11.5% of applicants to apply, wrongly
abandonment_rate_pct              9.5   <- our UX or our agents
document_gap_rate_pct            21.6   <- the size of the fixable problem
```

`our_fault_rate` is the one that matters. **A team reporting 0% is not accurate — it is not looking.** Publishing it is what separates you from every dashboard-driven welfare platform that came before, and it's the reason a Collector will eventually believe your other numbers.

## Where this closes the circuit

```
rules engine  →  needs  →  org matcher  →  referral  →  outcome  →  rules engine
                                                            ↓
                                              coverage gaps + policy findings
```

The outcome loop feeds the rules engine golden fixtures, feeds the org registry real `referral_outcomes`, and feeds the district administration the only honest picture anyone has of whether its own schemes reach people. That last output — not the app, not the database — is the thing that makes this project worth doing.
