"""
Golden test harness.

Every scheme carries fixture profiles with expected verdicts, authored by the
policy curator (NOT the engineer). Any rule edit runs the whole suite. This is
what catches "someone changed the income cap and silently excluded 40,000 people".

Run: python golden_tests.py
"""

import sys
from engine import Profile, load, evaluate_all, plan_next_questions, build_benefit_bundle

DICT_PATH = "fact_dictionary.json"
SCHEMES_PATH = "schemes/seed_schemes.json"

# (fixture_name, facts, {scheme_id: expected_verdict})
FIXTURES = [
    (
        "Sunita — pregnant, registered, has bank account, no govt job",
        {
            "gender": "female",
            "age": {"value": 24, "source": "document"},
            "is_pregnant": True,
            "pregnancy_registered_at_awc": True,
            "has_bank_account": True,
            "is_govt_employee_household": False,
            "receiving_central_maternity_benefit": False,
        },
        {"CENTRAL-MWCD-PMMVY-001": "LIKELY_ELIGIBLE"},
    ),
    (
        "Sunita — same, but NO bank account (the classic silent blocker)",
        {
            "gender": "female", "age": 24, "is_pregnant": True,
            "pregnancy_registered_at_awc": True,
            "has_bank_account": False,
            "is_govt_employee_household": False,
            "receiving_central_maternity_benefit": False,
        },
        {"CENTRAL-MWCD-PMMVY-001": "INELIGIBLE"},
    ),
    (
        "Sunita — pregnancy status unknown: must NOT be silently rejected",
        {"gender": "female", "age": 24, "has_bank_account": True},
        {"CENTRAL-MWCD-PMMVY-001": "NEEDS_INFO"},
    ),
    (
        "Ramesh — 45% disability certified, low income, MH, has bank",
        {
            "state_domicile": "MH",
            "age": {"value": 34, "source": "document"},
            "disability_percentage": {"value": 45, "source": "document"},
            "monthly_household_income": {"value": 8000, "source": "self_declared"},
            "has_bank_account": True,
            "has_udid": False,
            "receiving_state_disability_pension": False,
            "is_govt_employee_household": False,
            "ration_card_type": "PHH",
        },
        {
            "CENTRAL-DEPWD-ADIP-001": "LIKELY_ELIGIBLE",
            "CENTRAL-DEPWD-UDID-001": "LIKELY_ELIGIBLE",  # gateway
            "MH-SJSA-DISPEN-001": "INELIGIBLE",           # 8000*12 = 96k > 21k cap
            "CENTRAL-NSAP-IGNDPS-001": "INELIGIBLE",      # 45% < 80% severe threshold
        },
    ),
    (
        "Ramesh — self-declared disability only, no certificate: LIKELY not ELIGIBLE",
        {
            "state_domicile": "MH",
            "age": 34,
            "disability_percentage": {"value": 60, "source": "self_declared"},
            "monthly_household_income": {"value": 1000, "source": "self_declared"},
            "has_bank_account": True,
            "receiving_state_disability_pension": False,
            "is_govt_employee_household": False,
        },
        {"MH-SJSA-DISPEN-001": "LIKELY_ELIGIBLE"},
    ),
    (
        "Anjali — SC student, class 9, low income",
        {
            "is_student": {"value": True, "source": "document"},
            "education_stage": {"value": "class_9_10", "source": "document"},
            "social_category": {"value": "SC", "source": "document"},
            "annual_household_income": {"value": 90000, "source": "document"},
            "receiving_other_scholarship": {"value": False, "source": "verified_api"},
        },
        {"CENTRAL-MSJE-PREMATRIC-SC-001": "ELIGIBLE"},  # every consulted fact verified
    ),
    (
        "Anjali — already holds another scholarship: exclusion fires",
        {
            "is_student": True,
            "education_stage": "class_9_10",
            "social_category": {"value": "SC", "source": "document"},
            "annual_household_income": {"value": 90000, "source": "document"},
            "receiving_other_scholarship": True,
        },
        {"CENTRAL-MSJE-PREMATRIC-SC-001": "EXCLUDED"},
    ),
    (
        "Empty profile — everything must be NEEDS_INFO, nothing INELIGIBLE",
        {},
        {
            "CENTRAL-MWCD-PMMVY-001": "NEEDS_INFO",
            "CENTRAL-DEPWD-ADIP-001": "NEEDS_INFO",
            "MH-SJSA-DISPEN-001": "NEEDS_INFO",
            "CENTRAL-MSJE-PREMATRIC-SC-001": "NEEDS_INFO",
        },
    ),
]


def run():
    dictionary, schemes = load(DICT_PATH, SCHEMES_PATH)
    passed = failed = 0

    for name, facts, expectations in FIXTURES:
        profile = Profile(facts, profile_id=name)
        results = {r["scheme_id"]: r for r in evaluate_all(schemes, profile)}
        for sid, expected in expectations.items():
            got = results[sid]["verdict"]
            if got == expected:
                passed += 1
            else:
                failed += 1
                print(f"FAIL  {name}\n      {sid}: expected {expected}, got {got}")
                print(f"      failed={results[sid]['failed']}")
                print(f"      unknown={[u['fact'] for u in results[sid]['unknown']]}\n")

    print(f"\n{'='*66}\nGolden tests: {passed} passed, {failed} failed\n{'='*66}\n")
    return failed


def demo():
    dictionary, schemes = load(DICT_PATH, SCHEMES_PATH)

    print("DEMO 1 — cold start: what do we ask first?\n" + "-"*66)
    p = Profile({}, profile_id="new_household")
    for q in plan_next_questions(schemes, p, dictionary, top_n=6):
        tag = "  [SENSITIVE]" if q["sensitive"] else ""
        print(f"  score {q['score']:>5}  unblocks {q['unblocks_count']}  "
              f"{q['question']}{tag}")
        if q["justification"]:
            print(f"           -> must tell user: {q['justification']}")

    print("\n\nDEMO 2 — Ramesh, disability, conflict resolution\n" + "-"*66)
    p = Profile({
        "state_domicile": "MH",
        "age": {"value": 34, "source": "document"},
        "disability_percentage": {"value": 85, "source": "document"},
        "annual_household_income": {"value": 18000, "source": "document"},
        "ration_card_type": {"value": "PHH", "source": "document"},
        "has_bank_account": {"value": True, "source": "document"},
        "has_udid": {"value": False, "source": "document"},
        "receiving_state_disability_pension": {"value": False, "source": "document"},
        "is_govt_employee_household": {"value": False, "source": "document"},
        "monthly_household_income": {"value": 1500, "source": "document"},
    }, profile_id="ramesh")

    results = evaluate_all(schemes, p)
    bundle = build_benefit_bundle(results)

    print("  APPLY NOW:")
    for r in bundle["apply_now"]:
        gw = "  <- GATEWAY, do this first" if r["is_gateway"] else ""
        print(f"    [{r['verdict']:<16}] conf {r['confidence']}  {r['scheme_name']}{gw}")

    print("\n  DROPPED (conflict):")
    for d in bundle["dropped_due_to_conflict"]:
        print(f"    {d['scheme_name']}: {d['reason']}")

    print("\n  NOT ELIGIBLE (with reasons — this is what we show the citizen):")
    for r in bundle["not_eligible"]:
        why = (r["failed"] or r["excluded_by"])
        reason = why[0]["why"] if why else "-"
        print(f"    {r['scheme_name']}: {reason}")


if __name__ == "__main__":
    failures = run()
    demo()
    sys.exit(1 if failures else 0)
