"""
Referral matcher: given an unmet need from the rules engine, find the org that
can ACTUALLY take this person, this week.

Two ideas do the heavy lifting:

  1. Liveness decays with time since last contact. An org verified 8 months ago is
     a lead, not a referral. Decay is explicit and visible, not hidden in a stale flag.

  2. HARD constraints are filters, not scores. Capacity, block coverage, need match,
     female staff for a GBV case, blacklist status — these can never be traded off
     against a high score elsewhere. Scoring only ranks the survivors.

The failure this prevents: sending a woman in distress to a 'highly rated' org that
is 40km away, full, and has no female staff. A dead referral costs more than a
missing one, because it burns the trust that is the only asset a last-mile platform has.
"""

from __future__ import annotations
import json, math
from datetime import date
from typing import Optional

BLOCKING_STATUSES = {"DEFUNCT", "BLACKLISTED", "DORMANT"}

# Needs where referring to an org with no female staff is unacceptable, full stop.
FEMALE_STAFF_REQUIRED = {"GBV_SUPPORT", "SHELTER", "ANTENATAL_CARE",
                         "INSTITUTIONAL_DELIVERY_SUPPORT", "CHILD_PROTECTION"}

# Needs where we never auto-refer to an org funded by a party with a conflict.
CONFLICT_RULES = {"DEBT_DISTRESS": {"microfinance", "lender"}}


def liveness_score(org: dict, today: Optional[date] = None) -> float:
    """0.0-1.0. Halves roughly every 120 days since last verified contact.

    Explicit decay is the whole point: it forces the registry to be re-walked
    rather than quietly rotting while the UI keeps showing green ticks.
    """
    today = today or date.today()
    lv = org["liveness"]
    if lv["status"] in BLOCKING_STATUSES:
        return 0.0

    last = date.fromisoformat(lv["last_contact_at"])
    days = max((today - last).days, 0)
    recency = 0.5 ** (days / 120)

    base = {"VERIFIED_ACTIVE": 1.0, "PROBABLY_ACTIVE": 0.6, "UNREACHABLE": 0.2}[lv["status"]]

    # A field visit is worth far more than an unanswered email.
    method_weight = {"field_visit": 1.0, "referral_accepted": 1.0,
                     "phone": 0.85, "email": 0.5}.get(lv["last_contact_method"], 0.5)

    return round(base * recency * method_weight * (0.5 + 0.5 * lv["contact_success_rate_90d"]), 3)


MIN_LIVENESS_TO_REFER = 0.25
"""A low liveness score must HARD-BLOCK, never merely rank lower.

Learned the hard way from the first demo run: an org unreachable since November,
with 3 referrals sent and 3 abandoned, still ranked FIRST in a block where it was
the only listed option — because a decent-looking capacity number and a low waitlist
outweighed a liveness of 0.012. Ranking cannot be allowed to rescue a dead org just
because nothing better exists. If the only option is dead, the correct output is
'COVERAGE GAP', not a referral to a phone nobody answers.
"""


def hard_filter(org: dict, need_code: str, block_lgd: str,
                today: Optional[date] = None) -> tuple[bool, list[str]]:
    """Non-negotiable constraints. Returns (passes, reasons_for_rejection)."""
    reasons = []

    if org["liveness"]["status"] in BLOCKING_STATUSES:
        reasons.append(f"liveness={org['liveness']['status']}")

    live = liveness_score(org, today)
    if live < MIN_LIVENESS_TO_REFER:
        reasons.append(f"liveness {live} below referral floor {MIN_LIVENESS_TO_REFER} "
                       f"— stale/unverified, must be re-walked before use")
    if org["trust"]["escalation_status"] in ("suspended", "blacklisted"):
        reasons.append(f"escalation={org['trust']['escalation_status']}")

    caps = [c for c in org["capabilities"] if c["need_code"] == need_code]
    if not caps:
        reasons.append("does not serve this need")

    if block_lgd not in org["geography"]["operates_in_blocks"]:
        reasons.append(f"does not operate in {block_lgd}")

    rc = org["referral_capacity"]
    if not rc["accepts_referrals_from_third_parties"]:
        reasons.append("does not accept third-party referrals")
    if not rc["currently_accepting"]:
        reasons.append("intake closed")
    if rc["slots_used_this_month"] >= rc["monthly_intake_slots"]:
        reasons.append("no slots left this month")

    if need_code in FEMALE_STAFF_REQUIRED and not org["staff"]["has_female_staff"]:
        reasons.append("no female staff — hard block for this need type")

    banned_funders = CONFLICT_RULES.get(need_code, set())
    if banned_funders & set(org["funding"]["sources"]):
        reasons.append("conflict of interest with funder")

    if org["trust"]["red_flags"]:
        reasons.append(f"red flags: {org['trust']['red_flags']}")

    return (len(reasons) == 0), reasons


def rank_score(org: dict, block_lgd: str, today: Optional[date] = None) -> dict:
    """Rank the survivors of hard_filter. Internal only — never shown as a public rating."""
    live = liveness_score(org, today)

    out = org["trust"]["referral_outcomes"]
    sent = max(out["referrals_sent"], 1)
    acceptance = out["accepted"] / sent
    resolution = out["resolved"] / max(out["accepted"], 1)

    # Wilson-ish shrinkage: an org with 2/2 is not better than one with 36/40.
    confidence_in_track_record = sent / (sent + 10)

    rc = org["referral_capacity"]
    headroom = 1 - (rc["slots_used_this_month"] / max(rc["monthly_intake_slots"], 1))
    speed = 1 / (1 + rc["waitlist_days"] / 7)

    score = (
        0.35 * live +
        0.25 * (acceptance * confidence_in_track_record + 0.5 * (1 - confidence_in_track_record)) +
        0.20 * (resolution * confidence_in_track_record + 0.5 * (1 - confidence_in_track_record)) +
        0.10 * headroom +
        0.10 * speed
    )
    return {
        "score": round(score, 3),
        "liveness": live,
        "acceptance_rate": round(acceptance, 2),
        "resolution_rate": round(resolution, 2),
        "headroom": round(headroom, 2),
        "waitlist_days": rc["waitlist_days"],
    }


def find_referrals(orgs: list[dict], need_code: str, block_lgd: str,
                   top_n: int = 3, today: Optional[date] = None) -> dict:
    eligible, rejected = [], []

    for org in orgs:
        ok, reasons = hard_filter(org, need_code, block_lgd, today)
        if ok:
            m = rank_score(org, block_lgd, today)
            eligible.append({
                "org_id": org["org_id"],
                "name": org["canonical_name"],
                "contact": org["referral_capacity"]["referral_contact"],
                "channel": org["referral_capacity"]["referral_channel"],
                "can_share_beneficiary_data": org["data_sharing"]["signed_referral_mou"],
                **m,
            })
        else:
            rejected.append({"org_id": org["org_id"], "name": org["canonical_name"],
                             "reasons": reasons})

    eligible.sort(key=lambda x: -x["score"])

    # Stale-registry guard: if we have nothing live, say so. Do NOT fall back to a
    # dormant org just to have something to show. Show the govt delivery point instead.
    warning = None
    if not eligible:
        warning = (f"NO LIVE REFERRAL for {need_code} in {block_lgd}. "
                   f"Do not fabricate one. Route to the statutory delivery point "
                   f"(Tahsildar / district hospital / CDPO) and flag this as a "
                   f"COVERAGE GAP for the field team.")

    return {
        "need_code": need_code,
        "block": block_lgd,
        "referrals": eligible[:top_n],
        "rejected": rejected,
        "coverage_gap": warning,
    }


def coverage_report(orgs: list[dict], need_codes: list[str],
                    blocks: list[str], today: Optional[date] = None) -> list[dict]:
    """The map of holes. This, not the org count, is what you take to a funder or a Collector."""
    gaps = []
    for block in blocks:
        for need in need_codes:
            r = find_referrals(orgs, need, block, today=today)
            if not r["referrals"]:
                gaps.append({"block": block, "need_code": need, "live_orgs": 0,
                             "severity": "GAP"})
            elif len(r["referrals"]) == 1:
                gaps.append({"block": block, "need_code": need, "live_orgs": 1,
                             "severity": "SINGLE_POINT_OF_FAILURE"})
    return gaps


def load(path: str) -> list[dict]:
    with open(path) as f:
        return json.load(f)["organizations"]
