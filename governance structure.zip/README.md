# Governance — Start Here

```
GOVERNANCE.md      The charter: entity, locks, decision rights, wind-down
PRESSURE_TESTS.md  The ten requests that will be made, with pre-committed answers
```

*Not legal advice. Take this to an Indian corporate lawyer and a CA — entity choice, FCRA, and Section 8 have real consequences. What's here is the substance of what to lock down, and what will be attacked.*

---

## The premise

Almost all governance is theatre. Mission statements, values decks, advisory boards, privacy policies — every one survives exactly until it costs money.

Three things actually hold:

1. **Control someone else has**, that you can't take back
2. **A lock you can't pick yourself**, even when you badly want to
3. **A cost you pre-committed to paying**, in public, before you knew what it would cost

If a proposed mechanism is none of those three, it's decoration. Cut it.

## The five locks

| Lock | What it is | What it defends against |
|---|---|---|
| **1. Constitutional clause** | Prohibitions in the *Articles*, amendable only by 90% + Ethics Board consent + **90 days public notice** | Your own future self, quietly changing a policy on a Tuesday |
| **2. Golden share** | One share, no economic rights, veto over amendment and change of control — **held outside the company** | The acquisition, the investor, the pivot |
| **3. Data Trust** | The database is owned by a trust; the company is merely a *processor*; the licence auto-terminates on sale or insolvency | The liquidator, the acquirer's diligence lawyers |
| **4. Ethics Board** | 5–7 people, external chair, **real veto** over an enumerated list, own budget, right to publish dissent | The plausible pitch from someone you respect |
| **5. Transparency report** | Fixed quarterly date, including **data requests refused** and **own-agent bribe reports** | Everything — because it's the only thing an outsider can verify |

The amendment procedure in Lock 1 is the actual lock. **Anyone can write a prohibition. The question is how cheaply a future version of you can delete it.**

## The line that does the most work

> **Data requests refused, and from whom (category, not name) — published quarterly.**

Cheap to publish. Impossible to fake for long. The only way an outsider can tell whether your governance is real or a brochure. And it creates a standing disincentive against the request ever being made — which is the point.

## The tell

If holding the golden share yourself feels comfortable, **you've given it to the wrong party.** The whole purpose is that it's a power you gave away irrevocably, to someone who will use it against you when you're wrong.

## The scenario that actually gets you

Not the villain. Not the government. It's #7 in the pressure tests — **your own team, in a bad quarter:**

> *"We already have income, caste, disability, and household data. We could score credit risk. Lenders would pay. Access to credit is a real need for the poor — it's still helping them."*

There's no villain to point at. The argument is genuine. The person making it cares. You need revenue.

Every welfare-data organisation that became a scoring company got there through exactly this conversation, and **every one of them believed it was still helping.** That's what the Ethics Board veto is for — not the obvious bad actors, but the plausible pitch from someone you respect at the moment you're most tempted.

## The one where the answer is yes

Scenario #10, the flood. Emergency access is legitimate and you should grant it — **but design the shape of the yes now, while it's calm.** Declared emergency + Ethics Board chair sign-off in under two hours + minimum fields (phone, block, coarse vulnerability flag — *not caste, not religion*) + auto-expiring in 30 days + published after.

Because if you haven't built the legitimate emergency path, the emergency will be used to justify an illegitimate one — and you'll have no standing to object, since you'll be the organisation that refused to help during a flood.

**The emergency exception is how every surveillance system in history got built.** Build yours narrow, time-boxed, and audited, before you need it.

---

## Incorporation checklist

**Before you take a rupee of outside money:**

- [ ] Entity chosen (default: **Section 8**) — with counsel
- [ ] Constitutional clause drafted into the Articles, including the amendment procedure
- [ ] Golden share issued to a named external holder who is **not** you and **not** your lead investor
- [ ] Data Trust deed executed; company is a processor, not an owner; destruction covenant in place
- [ ] Ethics Board recruited — external chair, one member **from a beneficiary community, properly paid**
- [ ] Founders' public commitment signed *(resign and say why, if overruled)*
- [ ] Wind-down triggers written down, including the received-rate floor
- [ ] Field-agent contracts: fixed salary, no per-case pay, bribe = termination
- [ ] Whistleblower channel routing to the Ethics Board chair, not to management
- [ ] Transparency report template built, publication dates committed
- [ ] DPIA completed
- [ ] `PRESSURE_TESTS.md` read aloud with all co-founders — **note who hesitated, and where**

## The cost

Slower fundraising. Lost government contracts. A constrained pivot. **3–5% of opex** in board fees, audits, and legal.

That's the price of not building the most efficient targeting infrastructure for vulnerable people that India has ever had, and then hoping everyone who ever controls it turns out to be as good a person as you currently believe yourself to be.

**Hope is not a governance mechanism.**
