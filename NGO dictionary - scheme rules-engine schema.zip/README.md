# Welfare Scheme Rules Engine — Reference Implementation

Working skeleton of the scheme eligibility engine. Run `python golden_tests.py`.

```
fact_dictionary.json      Canonical facts. Rules may reference NOTHING else.
schemes/seed_schemes.json 7 schemes across the 3 pilot verticals (TEMPLATES, not verified policy)
engine.py                 Kleene evaluator, derivations, question planner, conflict bundler, audit
golden_tests.py           Fixture suite + demo
```

## The five invariants

1. **Rules are data, not code.** `engine.py` contains zero scheme-specific logic. Policy curators author JSON; engineers never touch a rule.
2. **Three-valued logic.** `UNKNOWN` propagates. It never collapses to `FALSE`. Silently rejecting someone because a field is blank is the precise failure this project exists to fix.
3. **Confidence comes from the *source* of a fact, never from a model.** Self-declared income and an income certificate are different facts. You can only say `ELIGIBLE` when every consulted fact is document- or API-verified. Otherwise `LIKELY_ELIGIBLE`.
4. **Every verdict is explainable and cited**, and carries the ruleset version it was computed under.
5. **Load-time validation.** A rule referencing an undefined fact raises on startup. This is the only thing that keeps the fact dictionary canonical as the catalogue grows.

## Verdicts

| Verdict | Meaning |
|---|---|
| `ELIGIBLE` | All criteria met, every consulted fact verified |
| `LIKELY_ELIGIBLE` | All criteria met, but some facts self-declared |
| `NEEDS_INFO` | One or more criteria unresolved — **ask, don't reject** |
| `INELIGIBLE` | A criterion definitively fails |
| `EXCLUDED` | An exclusion clause definitively fires |

Never show a citizen `ELIGIBLE` on the strength of self-declaration. A false promise costs more trust than a cautious "likely", and trust is the only asset a last-mile platform has.

## Question planner

`score(fact) = schemes_blocked_on_it / cost_to_collect`

Sensitive facts (caste, pregnancy, disability) are forced to the end of the queue and carry a `justification` string naming the schemes that require them. **You must be able to tell the person why you are asking before you ask.** Ranked non-sensitive-first, always.

Cold-start on this 7-scheme catalogue already surfaces the right lead question: *"Do you have a bank account in your own name?"* — the most common silent blocker in DBT.

## Conflict-aware bundling

Many schemes mutually exclude (state disability pension vs. IGNDPS). `build_benefit_bundle()` resolves the `conflicts_with` graph and returns the **best legal combination**, not a list of individually-eligible schemes. Gateway schemes (UDID) are surfaced first even though they pay nothing — they unlock everything downstream.

## Curator workflow (the part that decides whether this survives)

1. Curator finds the **Government Resolution / notification** — not the department website, which is stale.
2. Encodes the ruleset. Fills `provenance.gr_number`, `source_urls`, `last_verified`, `verified_by`.
3. Writes **5–15 golden fixtures** with expected verdicts, including the boundary cases.
4. Reviewer approves. CI runs the full fixture suite on every rule edit.
5. `review_cadence_days` elapses → `confidence` auto-degrades to stale → UI warns before anyone applies.

## The feedback loop that matters most

`applied → rejected at counter → why`.

That is how you discover the rule *as practised* differs from the rule *as written* — which it always does. Store it as a `field_note` on the rule. **Do not silently edit the official rule to match reality**; keep the two as distinct fields, or you lose the ability to tell a citizen they were wrongly denied.

## Known deliberate omissions

- No Aadhaar number storage anywhere. Only `has_aadhaar: bool`.
- Sensitive facts are tagged in the dictionary and drive DPDP retention/visibility policy (field agents should not see `is_pregnant` in plain text on shared devices).
- No ML anywhere in eligibility. ML belongs in *triage and outreach prioritisation*, never in deciding what someone is entitled to.

## Scaling notes

- 7 schemes here; ~50 hand-encoded is a realistic pilot target. **Do not scrape 2,000.** A large wrong database means telling a widow she qualifies for something she doesn't.
- The fact dictionary is the bottleneck asset. Get it canonical early; every new scheme should reuse existing facts ~80% of the time. If it doesn't, your dictionary is fragmenting.
