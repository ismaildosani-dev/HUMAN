# Pressure Tests

Every request below **will** be made. Each one is reasonable-sounding. Each is made by someone helpful, with budget or authority, in a room where you are outranked.

**Decide the answer now.** The whole value of a pre-commitment is that it was made when it was free.

Read this document aloud with your co-founders. If any of you hesitates on any scenario, that is the scenario that will break you.

---

## 1. The Collector's request

> *"Excellent work. Now share the list of beneficiaries in Khed block with the department so we can cross-verify against our records."*

**Answer:** No. Aggregates only.

**Say:** *"We can give you a full coverage map, gap analysis, and outcome data for Khed — including how many people your own office sanctioned who never received the money, which is a number you currently don't have. What we can't do is hand over the identified list. Every household consented to us telling *them* what they're entitled to, not to us handing their file to a department they haven't chosen to share it with. If a household wants to share with you, they can consent to that specifically, and we'll build the flow."*

**Why hold:** This is the request that converts a welfare tool into a targeting tool. It is *almost always* made in good faith — cross-verification is a genuine administrative need — which is exactly what makes it dangerous. The office will change hands. The state will change hands. The data will not un-share itself.

**The trade you offer instead:** the sanctioned→received gap for their own department. It is more useful to a competent Collector than a name list, and it costs you nothing.

---

## 2. The investor's term sheet

> *"We're in for the round. We'll need the standard data rights and a clean path to monetisation — the database is the asset here."*

**Answer:** No. Show them Lock 1 and Lock 3 in the term sheet, not after.

**Why hold:** An investor who walks over the constitutional clause has told you, for free, exactly what they intended to do with the data. That is a **cheap and extraordinarily valuable signal.** Thank them and move on.

**The version that's harder:** they don't object to the clause; they simply want the golden share held by a "mutually agreeable party" they later nominate. This is the same request, wearing a suit. Refuse.

---

## 3. The CSR funder's nudge

> *"We're funding the Pune pilot. Naturally we'd like our NGO partners to be the ones receiving the referrals."*

**Answer:** No. Funder identity does not enter the matcher's ranking inputs. Ever.

**Say:** *"Your partners get referrals whenever they're the best live option for that person, in that block, this month — same as everyone. If they're good, they'll get plenty. If we tilted the routing towards funders, the routing would be worthless, and so would we."*

**Why hold:** This is the softest, most reasonable-sounding, and most corrosive request on the list, because saying yes costs you nothing today and hurts nobody visibly. It is also precisely how referral platforms rot — quietly, in the ranking function, where no one can see it.

**Structural defence:** funder identity is not a field the matcher can read, and an outside party audits the routing annually. Make this true in code, not in policy, so that a well-meaning engineer under deadline pressure *cannot* do the favour.

---

## 4. The political approach

> *"The MLA's office would like to know which households in the constituency have pending applications, so they can help expedite them."*

**Answer:** No. Not aggregates either — not at ward level, not at any level that could support targeting.

**Why hold:** "Help expedite them" is not a lie. The MLA's office genuinely can expedite them. That is the problem. A benefit that arrives because a politician intervened is a benefit that can be withheld when a politician chooses — and you would have built the list that makes the withholding possible.

**Escalate this one to the Ethics Board immediately**, and record it in the transparency report as a refused request. The record is the protection. So is the fact that everyone knows you'll publish it.

---

## 5. The acquisition

> *"We're acquiring you. The data comes with the company — that's what we're buying."*

**Answer:** It does not. The Data Trust holds it; the processing licence terminates on change of control; the trustees must transfer to an equally-bound successor or destroy it within 30 days.

**Why this is the one that actually needs a legal lock:** you may not be in the room. You may be exhausted, out of money, and holding a term sheet that saves the jobs of forty people you hired. **This is the moment your good intentions are worth the least**, and it is precisely the moment the locks have to work without you.

Lock 3 exists so that the honest answer is *"I cannot,"* not *"I would rather not."*

---

## 6. The insolvency

> *"The creditors have a claim on all assets. That includes the database."*

**Answer:** The database was never an asset of the company. The company was a processor. The trust owns it, and the trust deed requires destruction.

**Get this right at incorporation or not at all.** No amount of goodwill retrofits it once a liquidator is appointed.

---

## 7. The mission-creep pitch — *from your own team*

> *"We already have income, caste, disability, and household data. We could score credit risk. Lenders would pay for it. It's still helping them — access to credit is a real need."*

**Answer:** No. Constitutional clause 4. This is a Section 8 asset and it will not be used to rank people for commercial gatekeeping.

**Why this is the most dangerous scenario on the list:** it comes from inside, from someone who cares, with a genuine argument (access to credit *is* a real need for the poor), at a moment when you need revenue. There is no villain to point at. Every welfare-data organisation that became a scoring company got there through exactly this conversation, and every one of them believed it was still helping.

**This is what the Ethics Board veto is for.** Not for the obvious villains — for the plausible pitch from the person you respect, at the moment you're most tempted.

---

## 8. The agent

> *"Three beneficiaries said our own field agent in Khed took ₹200 to fill their forms."*

**Answer:** Suspend today. Investigate. Terminate if substantiated. **Publish the number this quarter.**

**Why publish:** because your entire pitch is that you reduce corruption. An organisation that reduces corruption everywhere except in its own field team is not reducing corruption — it is relocating it and putting a nicer logo on it.

The quarter you publish a non-zero own-agent bribe number is the quarter anyone should start believing your other numbers.

---

## 9. The government portal integration

> *"Integrate with the state DBT system. We'll give you API access to beneficiary records — you'll be able to auto-verify eligibility."*

**Answer:** Yes to *read* access for verifying an individual's own status **with that individual's consent**, on demand, one record at a time.

**No** to bulk sync, no to a mirrored copy, no to standing access.

**Why the nuance matters:** this is a genuinely good offer. Verified facts make your rules engine dramatically better — `ELIGIBLE` instead of `LIKELY_ELIGIBLE`, fewer wasted trips to a counter. Take it. But **pull one record, with consent, at the moment of need. Never hold a mirror.** A mirror is a second honeypot with none of your protections and all of your liability.

---

## 10. The emergency

> *"There's a flood. We need every household in these three blocks with their phone numbers and vulnerability status, now."*

**Answer:** Yes — and this is the one where the answer is yes.

**But decide the shape of the yes now, while it's calm:**
- Life-safety is a lawful basis and a legitimate purpose. Have it enumerated as **P6_EMERGENCY** in the classification, with pre-agreed triggers.
- Trigger requires: a declared emergency by a competent authority, **plus** Ethics Board chair sign-off (which must be obtainable in under two hours — arrange this in advance, with a named alternate).
- Minimum necessary fields only: phone, block, and a coarse vulnerability flag. **Not caste. Not religion. Not income history.**
- **Auto-expiring access**, 30 days maximum.
- Logged, published in the transparency report, and reviewed after.

**Why pre-commit to a yes:** because if you have not designed the legitimate emergency path, the emergency will be used to justify an *illegitimate* one — and you will not have the standing to object, because you'll be the organisation that refused to help during a flood.

**The emergency exception is how every surveillance system in history got built.** Build yours narrow, time-boxed, and audited, before you need it.

---

## How to use this document

- Read it aloud with your co-founders, at incorporation.
- **The scenario where one of you hesitates is your real vulnerability.** Not the ones where you all nod.
- Give it to the Ethics Board on day one. Ask them where you're wrong.
- Re-read it every time you raise money, every time you sign a government MOU, and every time you hire someone senior.
- Add scenarios as they actually happen to you. The ones you didn't predict are the most valuable entries.
- When you refuse a request, **log it.** The refusals are the only evidence that any of this was real.
