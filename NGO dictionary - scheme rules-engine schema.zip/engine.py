"""
Welfare scheme eligibility engine.

Design invariants (do not break these without a design review):
  1. Rules are DATA. This module contains no scheme-specific logic.
  2. Three-valued logic. UNKNOWN never collapses to FALSE. Silently excluding
     someone because a field is blank is the exact failure this project exists to fix.
  3. Every verdict is explainable, cites its ruleset version, and is auditable.
  4. Confidence is derived from the SOURCE of facts, never from a model.
"""

from __future__ import annotations
import json, hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


# ---------------------------------------------------------------- three-valued logic

class TV(Enum):
    TRUE = "TRUE"
    FALSE = "FALSE"
    UNKNOWN = "UNKNOWN"

    def __and__(self, other: "TV") -> "TV":
        if self is TV.FALSE or other is TV.FALSE:
            return TV.FALSE
        if self is TV.UNKNOWN or other is TV.UNKNOWN:
            return TV.UNKNOWN
        return TV.TRUE

    def __or__(self, other: "TV") -> "TV":
        if self is TV.TRUE or other is TV.TRUE:
            return TV.TRUE
        if self is TV.UNKNOWN or other is TV.UNKNOWN:
            return TV.UNKNOWN
        return TV.FALSE

    def __invert__(self) -> "TV":
        if self is TV.TRUE:
            return TV.FALSE
        if self is TV.FALSE:
            return TV.TRUE
        return TV.UNKNOWN


# ---------------------------------------------------------------- facts

# Ordered weakest -> strongest. Determines whether a verdict can be ELIGIBLE or only LIKELY.
SOURCE_STRENGTH = {
    "inferred":      0.5,   # guessed from another signal
    "self_declared": 0.7,   # what the person told a field agent
    "derived":       0.8,   # computed from other facts; inherits the weakest parent
    "document":      0.95,  # agent saw a physical document
    "verified_api":  1.0,   # pulled from an authoritative government system
}
VERIFIED_SOURCES = {"document", "verified_api"}


@dataclass
class Fact:
    key: str
    value: Any
    source: str = "self_declared"
    as_of: Optional[str] = None

    @property
    def strength(self) -> float:
        return SOURCE_STRENGTH.get(self.source, 0.5)


class Profile:
    """A household/person profile. Missing != False. Absence is UNKNOWN."""

    def __init__(self, facts: Optional[dict[str, Any]] = None, profile_id: str = "anon"):
        self.profile_id = profile_id
        self.facts: dict[str, Fact] = {}
        for k, v in (facts or {}).items():
            if isinstance(v, Fact):
                self.facts[k] = v
            elif isinstance(v, dict) and "value" in v:
                self.facts[k] = Fact(k, v["value"], v.get("source", "self_declared"), v.get("as_of"))
            else:
                self.facts[k] = Fact(k, v)  # bare value -> self_declared

    def get(self, key: str) -> Optional[Fact]:
        return self.facts.get(key)

    def set(self, key: str, value: Any, source: str = "self_declared") -> None:
        self.facts[key] = Fact(key, value, source)

    def known(self, key: str) -> bool:
        f = self.facts.get(key)
        return f is not None and f.value is not None


# ---------------------------------------------------------------- derivations

def apply_derivations(profile: Profile) -> Profile:
    """Compute derived facts. Derived facts inherit the WEAKEST parent's source.

    Kept deliberately explicit rather than a generic expression engine: derivation
    bugs are silent and dangerous, so they should be readable by a policy curator.
    """
    # bpl_status <- ration_card_type
    if not profile.known("bpl_status") and profile.known("ration_card_type"):
        rc = profile.get("ration_card_type")
        profile.facts["bpl_status"] = Fact(
            "bpl_status", rc.value in ("AAY", "PHH"),
            source="derived" if rc.source in VERIFIED_SOURCES else rc.source,
        )

    # annual_household_income <- monthly_household_income * 12
    if not profile.known("annual_household_income") and profile.known("monthly_household_income"):
        m = profile.get("monthly_household_income")
        profile.facts["annual_household_income"] = Fact(
            "annual_household_income", m.value * 12,
            source="derived" if m.source in VERIFIED_SOURCES else m.source,
        )

    # monthly_household_income <- annual / 12
    if not profile.known("monthly_household_income") and profile.known("annual_household_income"):
        a = profile.get("annual_household_income")
        profile.facts["monthly_household_income"] = Fact(
            "monthly_household_income", a.value / 12,
            source="derived" if a.source in VERIFIED_SOURCES else a.source,
        )

    # has_disability_certificate <- a certified disability_percentage exists
    if not profile.known("has_disability_certificate") and profile.known("disability_percentage"):
        d = profile.get("disability_percentage")
        if d.source in VERIFIED_SOURCES:
            profile.facts["has_disability_certificate"] = Fact(
                "has_disability_certificate", True, source="derived")

    return profile


# ---------------------------------------------------------------- node evaluation

COMPARATORS = {
    "==": lambda a, b: a == b,
    "!=": lambda a, b: a != b,
    ">":  lambda a, b: a > b,
    ">=": lambda a, b: a >= b,
    "<":  lambda a, b: a < b,
    "<=": lambda a, b: a <= b,
    "IN":     lambda a, b: a in b,
    "NOT_IN": lambda a, b: a not in b,
}


@dataclass
class NodeResult:
    tv: TV
    fact_key: Optional[str]
    explanation: Optional[str]
    remedy: Optional[str] = None
    cite: Optional[str] = None
    sensitive: bool = False
    children: list["NodeResult"] = field(default_factory=list)


def eval_node(node: dict, profile: Profile) -> NodeResult:
    op = node.get("op")

    if op in ("AND", "OR"):
        kids = [eval_node(c, profile) for c in node.get("children", [])]
        if not kids:
            # An empty AND is vacuously TRUE; an empty OR (e.g. no exclusions) is FALSE.
            tv = TV.TRUE if op == "AND" else TV.FALSE
            return NodeResult(tv, None, None, children=[])
        acc = kids[0].tv
        for k in kids[1:]:
            acc = (acc & k.tv) if op == "AND" else (acc | k.tv)
        return NodeResult(acc, None, node.get("explain", {}).get(acc.value.lower()), children=kids)

    if op == "NOT":
        inner = eval_node(node["child"], profile)
        return NodeResult(~inner.tv, inner.fact_key, inner.explanation, children=[inner])

    # leaf
    key = node["fact"]
    fact = profile.get(key)
    explain = node.get("explain", {})

    if fact is None or fact.value is None:
        return NodeResult(
            TV.UNKNOWN, key,
            explain.get("unknown"),
            remedy=explain.get("remedy"),
            cite=node.get("cite"),
            sensitive=bool(node.get("requires_sensitive_fact")),
        )

    try:
        result = COMPARATORS[op](fact.value, node["value"])
    except (TypeError, KeyError):
        # Type mismatch is a DATA BUG, not a rejection. Never fail a citizen on our bug.
        return NodeResult(TV.UNKNOWN, key, f"Rule could not be evaluated for '{key}' (data type issue).",
                          cite=node.get("cite"))

    tv = TV.TRUE if result else TV.FALSE
    return NodeResult(
        tv, key,
        explain.get(tv.value.lower()),
        remedy=explain.get("remedy"),
        cite=node.get("cite"),
        sensitive=bool(node.get("requires_sensitive_fact")),
    )


def _collect(res: NodeResult, want: TV, out: list) -> None:
    if not res.children:
        if res.tv is want and res.fact_key:
            out.append(res)
        return
    for c in res.children:
        _collect(c, want, out)


# ---------------------------------------------------------------- scheme verdict

class Verdict(Enum):
    ELIGIBLE = "ELIGIBLE"              # all criteria met, ALL from verified sources
    LIKELY_ELIGIBLE = "LIKELY_ELIGIBLE"  # all criteria met, but some facts self-declared
    NEEDS_INFO = "NEEDS_INFO"          # one or more criteria unresolved
    INELIGIBLE = "INELIGIBLE"          # a criterion definitively fails
    EXCLUDED = "EXCLUDED"              # an exclusion clause definitively fires


def evaluate_scheme(scheme: dict, profile: Profile) -> dict:
    elig = eval_node(scheme.get("eligibility", {"op": "AND", "children": []}), profile)
    excl = eval_node(scheme.get("exclusions", {"op": "OR", "children": []}), profile)

    if excl.tv is TV.TRUE:
        verdict = Verdict.EXCLUDED
    elif elig.tv is TV.FALSE:
        verdict = Verdict.INELIGIBLE
    elif elig.tv is TV.UNKNOWN or excl.tv is TV.UNKNOWN:
        verdict = Verdict.NEEDS_INFO
    else:
        verdict = Verdict.ELIGIBLE  # provisionally; downgraded below on source strength

    failed, unknown, excluded_by = [], [], []
    _collect(elig, TV.FALSE, failed)
    _collect(elig, TV.UNKNOWN, unknown)
    _collect(excl, TV.TRUE, excluded_by)
    excl_unknown: list = []
    _collect(excl, TV.UNKNOWN, excl_unknown)
    unknown.extend(excl_unknown)

    # Confidence = weakest link among facts the rules actually consulted.
    consulted: list[str] = []
    def walk(n: NodeResult):
        if n.fact_key:
            consulted.append(n.fact_key)
        for c in n.children:
            walk(c)
    walk(elig); walk(excl)

    strengths = [profile.get(k).strength for k in set(consulted)
                 if profile.known(k)]
    confidence = min(strengths) if strengths else 0.0

    all_verified = all(
        profile.get(k).source in VERIFIED_SOURCES
        for k in set(consulted) if profile.known(k)
    )
    if verdict is Verdict.ELIGIBLE and not all_verified:
        # Never tell someone they ARE eligible on the strength of self-declaration.
        # A Tahsildar with an income certificate may disagree, and a false promise
        # costs more trust than a cautious "likely".
        verdict = Verdict.LIKELY_ELIGIBLE

    # Documents the person doesn't yet hold that this scheme requires.
    doc_fact_map = {
        "income_certificate": "has_income_certificate",
        "caste_certificate": "has_caste_certificate",
        "domicile": "has_domicile_certificate",
        "disability_certificate": "has_disability_certificate",
        "bank_passbook": "has_bank_account",
        "aadhaar": "has_aadhaar",
    }
    blocking_docs = [
        d for d in scheme.get("documents_required", [])
        if (fk := doc_fact_map.get(d)) and profile.known(fk) and profile.get(fk).value is False
    ]

    return {
        "scheme_id": scheme["scheme_id"],
        "scheme_name": scheme["canonical_name"],
        "vertical": scheme.get("vertical"),
        "verdict": verdict.value,
        "confidence": round(confidence, 2),
        "is_gateway": bool(scheme.get("is_gateway")),
        "unlocks": scheme.get("unlocks", []),
        "conflicts_with": scheme.get("conflicts_with", []),
        "failed": [{"fact": n.fact_key, "why": n.explanation, "cite": n.cite} for n in failed],
        "unknown": [{"fact": n.fact_key, "question": n.explanation,
                     "remedy": n.remedy, "sensitive": n.sensitive} for n in unknown],
        "excluded_by": [{"fact": n.fact_key, "why": n.explanation} for n in excluded_by],
        "blocking_documents": blocking_docs,
        "next_actions": [n.remedy for n in (failed + unknown) if n.remedy],
        "ruleset_version": scheme.get("version"),
        "provenance_confidence": scheme.get("provenance", {}).get("confidence"),
        "stale": scheme.get("provenance", {}).get("last_verified") is None,
        "evaluated_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------- question planner

def plan_next_questions(schemes: list[dict], profile: Profile,
                        dictionary: dict, top_n: int = 5) -> list[dict]:
    """Rank unknown facts by information gain.

    score = (#schemes currently blocked on this fact) / cost_to_collect

    Sensitive facts (caste, pregnancy, disability) are pushed to the end and
    carry the list of schemes that justify asking — you must be able to tell the
    person WHY you are asking before you ask.
    """
    facts_meta = dictionary["facts"]
    blocked: dict[str, list[str]] = {}

    for s in schemes:
        r = evaluate_scheme(s, profile)
        if r["verdict"] != "NEEDS_INFO":
            continue
        for u in r["unknown"]:
            blocked.setdefault(u["fact"], []).append(s["canonical_name"])

    ranked = []
    for fact_key, schemes_blocked in blocked.items():
        meta = facts_meta.get(fact_key, {})
        cost = meta.get("cost_to_collect", 2)
        sensitive = meta.get("sensitivity") == "high"
        ranked.append({
            "fact": fact_key,
            "question": (meta.get("ask") or {}).get("en", f"Please provide: {fact_key}"),
            "unblocks_count": len(schemes_blocked),
            "unblocks": schemes_blocked,
            "sensitive": sensitive,
            "justification": (
                f"Needed for: {', '.join(schemes_blocked[:3])}" if sensitive else None
            ),
            "score": round(len(schemes_blocked) / cost, 2),
        })

    # non-sensitive first, then by score. Never lead an interview with caste.
    ranked.sort(key=lambda x: (x["sensitive"], -x["score"]))
    return ranked[:top_n]


# ---------------------------------------------------------------- conflict-aware bundle

def build_benefit_bundle(results: list[dict]) -> dict:
    """Given per-scheme verdicts, produce the best LEGAL combination.

    Two schemes that conflict cannot both be claimed. We keep the one the person
    is more likely to actually get (higher confidence, then verified verdict).
    Gateway schemes (e.g. UDID) are always surfaced first even though they pay
    nothing — they are what unlocks everything downstream.
    """
    claimable = [r for r in results if r["verdict"] in ("ELIGIBLE", "LIKELY_ELIGIBLE")]
    by_id = {r["scheme_id"]: r for r in claimable}

    dropped = []
    kept: set[str] = set(by_id)
    for r in claimable:
        if r["scheme_id"] not in kept:
            continue
        for cid in r["conflicts_with"]:
            if cid in kept and cid != r["scheme_id"]:
                a, b = r, by_id[cid]
                loser = min((a, b), key=lambda x: (x["confidence"], x["verdict"] == "ELIGIBLE"))
                winner = a if loser is b else b
                kept.discard(loser["scheme_id"])
                dropped.append({
                    "scheme_id": loser["scheme_id"],
                    "scheme_name": loser["scheme_name"],
                    "reason": f"Cannot be combined with {winner['scheme_name']}; "
                              f"{winner['scheme_name']} is the stronger claim.",
                })

    bundle = [by_id[i] for i in kept]
    gateways = [r for r in bundle if r["is_gateway"]]
    others = [r for r in bundle if not r["is_gateway"]]

    return {
        "apply_now": gateways + sorted(others, key=lambda r: -r["confidence"]),
        "dropped_due_to_conflict": dropped,
        "needs_more_info": [r for r in results if r["verdict"] == "NEEDS_INFO"],
        "not_eligible": [r for r in results
                         if r["verdict"] in ("INELIGIBLE", "EXCLUDED")],
    }


# ---------------------------------------------------------------- audit

def audit_record(profile: Profile, results: list[dict], dictionary_version: int) -> dict:
    """Immutable record of exactly what we told this person and why.

    This is your feedback loop when they are rejected at the counter, and your
    legal defence when someone claims you misadvised them. Never overwrite; append.
    """
    payload = {
        "profile_id": profile.profile_id,
        "facts_snapshot": {k: {"value": f.value, "source": f.source}
                           for k, f in profile.facts.items()},
        "dictionary_version": dictionary_version,
        "results": [{"scheme_id": r["scheme_id"], "verdict": r["verdict"],
                     "ruleset_version": r["ruleset_version"],
                     "confidence": r["confidence"]} for r in results],
        "evaluated_at": datetime.now(timezone.utc).isoformat(),
    }
    payload["hash"] = hashlib.sha256(
        json.dumps(payload, sort_keys=True).encode()).hexdigest()[:16]
    return payload


# ---------------------------------------------------------------- loading

def load(dict_path: str, schemes_path: str) -> tuple[dict, list[dict]]:
    with open(dict_path) as f:
        dictionary = json.load(f)
    with open(schemes_path) as f:
        schemes = json.load(f)["schemes"]
    validate_rules_against_dictionary(schemes, dictionary)
    return dictionary, schemes


def validate_rules_against_dictionary(schemes: list[dict], dictionary: dict) -> None:
    """Fails loudly at load time if a rule references a fact that doesn't exist.
    This is the guardrail that keeps the fact dictionary canonical."""
    known = set(dictionary["facts"])
    problems = []

    def walk(node, sid):
        if "children" in node:
            for c in node["children"]:
                walk(c, sid)
        elif "child" in node:
            walk(node["child"], sid)
        elif "fact" in node and node["fact"] not in known:
            problems.append(f"{sid}: unknown fact '{node['fact']}'")

    for s in schemes:
        walk(s.get("eligibility", {}), s["scheme_id"])
        walk(s.get("exclusions", {}), s["scheme_id"])

    if problems:
        raise ValueError("Rules reference undefined facts:\n  " + "\n  ".join(problems))


def evaluate_all(schemes: list[dict], profile: Profile) -> list[dict]:
    profile = apply_derivations(profile)
    return [evaluate_scheme(s, profile) for s in schemes]
