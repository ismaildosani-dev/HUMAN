# DPDP-Compliant Data Architecture

Not legal advice — I'm not a lawyer, and DPDP rules have been evolving. This is an architecture that makes compliance *achievable* and gets you a productive first meeting with counsel. Most of it is deliberately stricter than the law requires.

```
data_classification.json  Tiers, purposes, roles, retention — and the REFUSAL LIST
policy_engine.py          Enforcement at the access boundary + consent artifact
demo.py                   9 scenarios incl. the three attacks that actually happen
```

Run `python demo.py`.

## The first principle

You are building a database of India's most vulnerable people, indexed by caste, religion, disability, pregnancy, income, and home address.

Before every design decision: *if this leaked tomorrow, or were subpoenaed, or sold in a distress acquisition, or quietly queried by a party worker before an election — who gets hurt, and how badly?*

**The strongest privacy control is not encryption. It is not collecting the data.** Every field in the classification had to justify its own existence.

## The refusal list

Write this into your engineering docs **and your articles of association**, before the pressure arrives. It always arrives.

**Never store:** Aadhaar number (store `has_aadhaar: bool` — the number gives you zero function and makes you a national honeypot) · biometrics · precise GPS of a dwelling (a lat/lng of a Dalit household or a GBV survivor's home is a targeting list; store the LGD code) · bank account numbers · voter ID or political affiliation · **free-text agent notes on a person** (unstructured notes accumulate stigmatising, unverifiable, un-deletable judgements — "drinks", "husband is trouble").

**Never do:** sell or license the database, ever · bulk-export beneficiary lists to any department or political actor · compute a public socio-economic score attached to a person · train a model on identified beneficiary data (models memorise).

## Three controls do most of the work

**1. Purpose binding.** Every read declares a purpose; the purpose gates which tiers it can touch. Enforced in the function that returns the data — not in a policy PDF, not in a code-review checklist. *If a developer can write `SELECT * FROM profiles` and get a caste column back, you have a compliant document, not a compliant system.*

**2. Write-without-read on T2.** The field agent **enters** caste, disability, pregnancy. He can never read them back, list them, or export them. This single control kills the "agent walks off with a list of pregnant Dalit women in his block" scenario — which is the realistic insider threat, not a Hollywood breach.

**3. Named-recipient consent.** Consent to *be helped* is never consent to send data to Org X. The org is named at consent time, every time. Scenario 5 in the demo is the one that matters: a new CSR partner signs next quarter, someone says "just route the existing cases to them," and the system refuses.

## The consent script

Six lines, read aloud, under sixty seconds, in her language, audio-recorded with permission.

Note what is *not* in it: no "data controller," no "processing," no "as described in our privacy policy." A consent script a person cannot understand is not a consent script — it's a liability shield, and it won't shield you anyway.

The most important line, and the one everyone omits:

> *"You can say no. Saying no will not reduce any government entitlement you already have."*

Without it, consent given to a stranger who appears to control access to benefits is not freely given, and therefore is not consent. A checkbox ticked by a field agent on behalf of a woman who cannot read is paperwork, not permission.

## Fail closed

An unclassified fact defaults to **T2_SENSITIVE**, not T0. A field someone added last sprint must not silently become visible to every field agent in the district.

Denied fields are **absent** from the response, not `None` — otherwise a caller can distinguish "she has no caste certificate" from "you may not see her caste," and that distinction is itself a leak.

The audit log records fact **keys and verdicts, never values**. An audit log of who-looked-at-whose-caste is itself a caste database.

## Deletion must run

`retention_sweep` is wired to a cron and alerts if it hasn't run in 48h. A retention rule that has never actually deleted anything is not a control — it's a claim. Case closed → T2 purged at 90 days. Dormant 24 months → full purge. T3 crisis records → 365 days, unconditional.

## The government question

This is where the project lives or dies, so decide it now, in writing.

Departments get **P4 aggregates by default**. Case-level access requires the beneficiary's explicit, named, per-department consent — and only for a department actually delivering *her* benefit.

*"Give us the list of beneficiaries in this ward"* is the request that converts a welfare tool into a targeting tool. It will be made politely, by someone helpful, who has budget. **Refuse it in code, not in a meeting** — because in the meeting you will be outranked.

Corollary: aggregates need real k-anonymity. Two GBV cases in Mulshi block is not a statistic; it is two identifiable women. Suppress cells below k=25. The coverage map is exactly where small cells appear.

## Consider not holding crisis data at all

For GBV, child protection, trafficking, mental-health crisis: **warm-transfer to the statutory body** (One-Stop Centre, Childline 1098, DLSA) and store only `referred_to_crisis_service: true`. The counselling record belongs to her and to the receiving org — not to you. You gain nothing by holding it and you can get someone killed by leaking it.

## Known tension, stated honestly

`build_referral_payload` sends `disability_percentage` (T2) to a disability org, even though purpose P2_REFERRAL nominally excludes T2. That's a deliberate carve-out — the org literally cannot help without it — enforced through an explicit need→facts allowlist rather than by tier. It's the right call, but it *is* the crack where scope creep will start. Review that allowlist every time it changes, and make the diff visible to whoever holds your ethics mandate.

## What I'd add next

- **Independent ethics board with civil-society members**, with a real veto over data-sharing decisions — not an advisory panel.
- **Publish your refusal count**: how many times you declined a bulk-data request, and from whom. It's the only credible signal, and it's cheap.
- **DPIA before the pilot**, not after.
- A **breach playbook** rehearsed once, before you have real data to lose.
