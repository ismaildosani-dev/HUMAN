from datetime import date
from matcher import load, find_referrals, coverage_report, liveness_score

TODAY = date(2026, 7, 12)
orgs = load("sample_orgs.json")

print("LIVENESS DECAY (why a registry rots)\n" + "-" * 70)
for o in orgs:
    lv = o["liveness"]
    print(f"  {liveness_score(o, TODAY):>6}  {o['canonical_name'][:44]:<46} "
          f"[{lv['status']}, last {lv['last_contact_method']} {lv['last_contact_at']}]")

print("\n\nCASE 1 — Ramesh, Haveli block, needs a disability certificate\n" + "-" * 70)
r = find_referrals(orgs, "DISABILITY_CERTIFICATE_ASSISTANCE", "MH-PUN-HAVELI", today=TODAY)
for x in r["referrals"]:
    mou = "data-share OK" if x["can_share_beneficiary_data"] else "NO MOU — citizen walks in themselves"
    print(f"  -> {x['name']}")
    print(f"     score {x['score']}  live {x['liveness']}  "
          f"accept {x['acceptance_rate']}  resolve {x['resolution_rate']}  "
          f"wait {x['waitlist_days']}d  ({mou})")
print("  REJECTED:")
for x in r["rejected"]:
    print(f"     {x['name'][:50]:<52} {x['reasons']}")

print("\n\nCASE 2 — same need, but in KHED block\n" + "-" * 70)
r = find_referrals(orgs, "DISABILITY_CERTIFICATE_ASSISTANCE", "MH-PUN-KHED", today=TODAY)
for x in r["referrals"]:
    print(f"  -> {x['name']} (score {x['score']})")
print("  REJECTED:")
for x in r["rejected"]:
    print(f"     {x['name'][:50]:<52} {x['reasons']}")
if r["coverage_gap"]:
    print(f"\n  !! {r['coverage_gap']}")

print("\n\nCASE 3 — pregnant woman, Mulshi, needs antenatal care\n" + "-" * 70)
r = find_referrals(orgs, "ANTENATAL_CARE", "MH-PUN-MULSHI", today=TODAY)
for x in r["referrals"]:
    print(f"  -> {x['name']} (score {x['score']})")
if r["coverage_gap"]:
    print(f"  !! {r['coverage_gap']}")
print("  REJECTED:")
for x in r["rejected"]:
    print(f"     {x['name'][:50]:<52} {x['reasons']}")

print("\n\nCOVERAGE MAP — the holes, not the org count\n" + "-" * 70)
needs = ["DISABILITY_CERTIFICATE_ASSISTANCE", "ASSISTIVE_DEVICE",
         "ANTENATAL_CARE", "BANK_ACCOUNT_OPENING", "SCHOLARSHIP_APPLICATION"]
blocks = ["MH-PUN-HAVELI", "MH-PUN-MULSHI", "MH-PUN-KHED", "MH-PUN-JUNNAR"]
for g in coverage_report(orgs, needs, blocks, today=TODAY):
    mark = "GAP " if g["severity"] == "GAP" else "SPOF"
    print(f"  [{mark}] {g['block']:<16} {g['need_code']}")
print("\n  ^ THIS is the artefact you take to the District Collector and to funders.")
