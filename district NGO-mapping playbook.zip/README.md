# District NGO-Mapping Playbook

Pairs with the rules engine. The engine says *what someone is entitled to*; this says *who will actually help them get it*, in their block, this month.

```
org_schema.json           Registry schema — the referral-capacity model
matcher.py                Liveness decay, hard filters, ranking, coverage report
sample_orgs.json          4 illustrative orgs (incl. a registry ghost and a red-flag org)
demo.py                   Run this: python demo.py
verification_protocol.md  The phone script and field protocol — the part that can't be coded
```

## The core insight

NGO Darpan has ~1 lakh+ registered organisations. That number is nearly worthless to you. Four things are not in any registry, and they are the only things that matter:

1. **Is it alive?** (30–40% aren't)
2. **Does it work in *this block*?** — not "Pune district," which is useless to someone in Junnar
3. **Does it do *this specific thing*?**
4. **Can it take one more case *this month*?**

Building that is field work. It's also why nobody has done it, and why it's defensible.

## Liveness decays — make it visible

`liveness_score` halves roughly every 120 days since last contact, weighted by contact method (field visit ≫ phone ≫ email) and 90-day contact success rate. In the demo, a Darpan-registered org unreachable since November scores **0.012**.

**Below 0.25 → hard-blocked from referrals**, even if it's the only option in the block. This was learned from the first demo run, where that dead org ranked *first* in Khed because its (fabricated) capacity numbers looked good and nothing better existed. Ranking must never be allowed to rescue a corpse. If the only option is dead, the honest output is `COVERAGE GAP`, not a referral to a phone nobody answers.

## Hard filters are filters, never scores

Capacity, block coverage, need match, red flags, escalation status, and **female staff for GBV/shelter/maternal cases** are non-negotiable. They cannot be traded off against a strong score elsewhere. Scoring only ranks the survivors.

The failure this prevents: sending a woman in distress to a "highly rated" org that is 40km away, at capacity, with no female staff. **A dead referral costs more than a missing one** — it burns the trust that is a last-mile platform's only real asset.

## No public trust rating

`trust` publishes component signals (acceptance rate, resolution rate, years operating, vouched-by, red flags). It does **not** compute a single public score. A public rating on an NGO becomes a gatekeeping surface, a rent-seeking surface, and a defamation exposure. Rank internally; disclose components.

## What you publish

Not "we mapped 340 NGOs." That's a vanity metric.

```
[GAP ] MH-PUN-KHED     DISABILITY_CERTIFICATE_ASSISTANCE
[GAP ] MH-PUN-JUNNAR   DISABILITY_CERTIFICATE_ASSISTANCE
[GAP ] MH-PUN-MULSHI   SCHOLARSHIP_APPLICATION
[SPOF] MH-PUN-HAVELI   ASSISTIVE_DEVICE
```

The coverage map is the artefact. It gets you the meeting with the District Collector, gives a CSR funder something they can actually act on, and is the honest answer to *"what do you know that we don't?"*

## 12-week pilot — one district, three verticals

| Weeks | Work | Exit criterion |
|---|---|---|
| 1 | Harvest Darpan + CSR portal + FCRA + **district admin panel** + statutory bodies (DLSA, DCPU, OSC, DDRC). Dedup on registration no. | ~600 raw rows, ranked by call priority |
| 2–4 | **Call the top 150.** 10-min script. Snowball for 2 more names each. Log unreachables. | ~60 `PROBABLY_ACTIVE`, ghost list pruned |
| 5–6 | **Field-visit ~40.** Case files, staff, accessibility, ask a beneficiary about money. | ~35 `VERIFIED_ACTIVE` with real capacity numbers |
| 7 | Publish the coverage map. Take it to the Collector's office. | Gaps named, per block, per need |
| 8–11 | **Run 200 households end to end.** Rules engine → needs → matcher → referral → follow up by phone. Humans and a spreadsheet. | Real acceptance/resolution rates in `referral_outcomes` |
| 12 | Measure the only metric that matters: **benefit actually received, in hand.** Not profiles created, not schemes surfaced, not referrals sent. | Honest conversion number |

Then decide what to automate. Not before.

## Three ways this gets corrupted

1. **Your field agent becomes the new middleman.** Fixed salary, never per-case. Audit by calling beneficiaries and asking what they paid. Publish that number.
2. **Routing gets captured by your funder.** Keep funder identity entirely out of the ranking inputs. Have someone outside the company audit the routing.
3. **You map orgs instead of gaps.** Mapping is legible, fundable, comfortable. Gaps are embarrassing and hard. Only one of them changes anything.
